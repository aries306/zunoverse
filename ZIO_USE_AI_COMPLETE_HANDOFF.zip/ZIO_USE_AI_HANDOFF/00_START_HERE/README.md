# ZIO — USE AI COMPLETE TAKEOVER PACKAGE

This package is the handoff for taking over the ZIO project in another AI/build environment.

## Read in this order
1. `04_BUILDER_INSTRUCTIONS/00_MASTER_TAKEOVER_INSTRUCTIONS.md`
2. `04_BUILDER_INSTRUCTIONS/01_COPY_PASTE_MASTER_PROMPT.md`
3. `05_AUDIT_AND_TRUTH/02_CURRENT_STATE_AND_RELEASE_GATE.md`
4. `05_AUDIT_AND_TRUTH/01_ARCHITECTURE_AND_CAPABILITY_MAP.md`
5. Then inspect `01_APPLICATION_ARCHIVES/` and `02_PROJECT_HISTORY/`.

## Important
The original XIO 4.0, 4.2 and 5.0 application ZIPs are preserved unchanged. They are historical source artifacts, not automatically the canonical current implementation.

The product was subsequently renamed XIO → ZIO. Internal infrastructure identifiers may still legitimately retain XIO names when changing them would break configuration or secrets.
