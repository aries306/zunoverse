# CURRENT STATE + RELEASE GATE

## Verified direction from project history
- Product renamed XIO → ZIO.
- Shadow visible identity evolved to NEXUS.
- Workspace and public experience are intended to be one ecosystem.
- Backend authority, graph validation, connector privacy and evidence-backed ZIO-EFFECT were explicitly hardened in later work.
- Source Fabric research can feed NEXUS context.
- GitHub OAuth path was prepared for real authorization and sync.
- Astara is intended as persistent conversational intelligence, not a task-only chatbot.
- Founder/XIO narrative voice and Astara conversational voice are intentionally separate.

## Known dependencies / caveats
Credential-dependent integrations must be verified in the target environment. Never assume a historical secret is still available or bound.

Historical voice work specifically identified ElevenLabs provisioning/credential state as a dependency. GitHub work identified OAuth client credentials and token encryption configuration as dependencies. Do not put secrets into chat or source control.

## Health truth
The correct goal is not to make the dashboard show 100%. The goal is for every health number to be mathematically explainable and causally correct. Health should be based on actual work-bearing entities rather than intelligence/telemetry records.

## Production gate
A clean deployment snapshot (for example, 0 frontend/network/backend errors) is useful but is not sufficient evidence of production readiness.

Production evaluation requires the real end-to-end loop:
Outcome → Work → Graph → NEXUS → Context/Memory/Research/Learning → Recommendation → Approval → Action → Verification → Learning.

## Human alpha gate
Once the core loop is trustworthy, test with real people and real goals.

Measure:
- whether people understand ZIO without explanation
- whether they can express outcomes
- whether NEXUS recommendations are trusted/useful
- whether memory helps later
- whether source context improves decisions
- whether actions actually help
- whether users return
- what users attempt that the designers did not anticipate

The key product test:
**Did ZIO make the person more capable than before they opened it?**
