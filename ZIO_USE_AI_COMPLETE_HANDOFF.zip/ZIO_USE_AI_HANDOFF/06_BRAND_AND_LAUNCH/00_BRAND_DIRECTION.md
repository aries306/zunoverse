# ZIO BRAND + LAUNCH DIRECTION

## Brand architecture
ZIO = the world / intelligent work environment
NEXUS = the intelligence inside ZIO
Astara = the conversational intelligence users meet
ZIO-EFFECT = measurable value

Narrative:
**Shadow was the beginning. NEXUS is what it became.**

## Public experience
Desired first-contact idea:
**What do you want to make possible?**

Visual direction:
- premium
- intelligent
- cinematic
- restrained
- signal/connection motifs
- evolving network/graph language
- no generic robot imagery
- no generic corporate AI stock aesthetic

The experience should progress from:
**Intelligence → Context → Memory → Connection → Momentum → ZIO → Astara → ZIO-EFFECT**

## Launch narrative
Do not overclaim current production maturity. Position the vision and demonstrate what is genuinely working.

Campaign angles already explored:
1. Cinematic mystery
2. Founder story
3. “What if?” curiosity
4. The AI shift
5. NEXUS reveal

## Domain strategy
Historical work recommended keeping the distinctive XIO/ZIO brand architecture rather than forcing an exact domain that is crowded or unavailable. Verify current domain and trademark conditions before committing.
