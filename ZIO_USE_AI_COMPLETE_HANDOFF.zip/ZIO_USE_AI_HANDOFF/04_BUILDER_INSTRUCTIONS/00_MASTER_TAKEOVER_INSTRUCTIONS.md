# ZIO MASTER TAKEOVER INSTRUCTIONS

## Mission
Take over ZIO as an existing product. Do not restart it. Reconcile everything already built into one coherent, trustworthy intelligence ecosystem.

## Vision
ZIO is **the Intelligence Layer for Your Ambition** and the intended intelligent work environment connecting:

Human intelligence + AI intelligence + context + memory + learning + knowledge + reasoning + agents + tools + execution + feedback.

ZIO should not feel like a chatbot, project manager, AI wrapper, or collection of disconnected features. It should feel like one living intelligence environment that helps a person understand, decide, create, execute, verify and learn.

## Product architecture

ZIO = the world/ecosystem
- Public ZIO = front door and first-contact experience
- Authenticated Workspace = actual environment
- Astara = conversational intelligence/personality
- NEXUS = intelligence/orchestration layer; evolved from Shadow
- Memory Fabric = governed contextual memory
- Learning Genome = accumulated evidence-based learning
- Work Graph = relationships across work, knowledge, context and entities
- Source Fabric = authorized external-source ingestion
- ZIO-EFFECT = measurable value/outcome layer
- Agents = specialized capabilities
- Tools = execution/connection layer

The old separate builds are development history, not separate customer products.

## Canonical intelligence loop

OUTCOME
→ WORK
→ WORK GRAPH
→ CONTEXT
→ MEMORY + RESEARCH + LEARNING
→ NEXUS
→ OBSERVE
→ CONNECT
→ RECALL
→ REASON
→ RECOMMEND
→ HUMAN APPROVAL
→ ACT
→ VERIFY
→ LEARN
→ governed MEMORY / LEARNING GENOME
→ improved future recommendations

## Core principles
1. Intelligence should compound.
2. Context beats generic capability.
3. Memory belongs to the person/workspace and is governed.
4. AI amplifies agency; it does not silently take control.
5. Intelligence should move toward useful action.
6. Learning never stops.
7. Trust is a feature.
8. The interface should disappear when intelligence works.
9. Evidence beats claims.
10. Do not build cosmetic complexity before making the core loop real.

## Contextual Memory — non-negotiable
Memory is not a bag of permanent facts and not a transcript dump.

Each meaningful memory should preserve, where applicable:
- content
- context
- scope
- provenance
- confidence
- lifecycle
- verification/approval state
- relevance/use metadata

Important memories should not vanish merely because their original conversation ended. They may become dormant and become relevant again when context returns.

Before memory influences a recommendation, re-evaluate its relevance and confidence.

Keep distinct:
**Memory ≠ Belief ≠ Pattern ≠ Insight ≠ Learning ≠ Recommendation**

A past user statement is not automatically permanent truth.

## Astara
Astara is the conversational intelligence users meet.

She should:
- support normal conversation, not force everything into task mode
- be curious, perceptive and useful
- retain relevant context without storing everything indiscriminately
- discuss broad subjects within capability
- challenge ideas respectfully
- support exploration, learning, decisions and execution
- express a perspective without pretending to be human
- avoid repetitive corporate-assistant language

Astara is the conversational interface; NEXUS is the deeper intelligence/orchestration layer.

## NEXUS
NEXUS evolved from Shadow.

Narrative:
**Shadow was the beginning. NEXUS is what it became.**

NEXUS must:
- observe workspace state
- understand current context
- connect entities and evidence
- retrieve relevant memory and learning
- reason over combined context
- produce high-leverage recommendations
- show confidence/evidence where meaningful
- propose actions
- respect approval boundaries
- execute approved actions
- verify outcomes
- create evidence-backed learning

Never claim an action happened unless the system actually executed and recorded it.

## Workbench / Work Graph
The canonical workspace should unify:
Projects, Tasks, Milestones, Outcomes, Documents, Research, Decisions, Memory, Learning, Activity, Conversations, Sources, NEXUS and Astara.

The Work Graph is real infrastructure, not decorative visualization. Server-side validation must ensure:
- valid node type
- valid node ID
- entity exists
- entity belongs to the current user/tenant
- relationships are valid

## Source Fabric
Target connector family:
- GitHub
- Google Drive
- Notion
- Slack
- Linear

Prove one adapter end-to-end first — GitHub is the reference.

Target flow:
AUTHORIZED SOURCE
→ ingestion/sync
→ Research
→ Work Graph/context
→ NEXUS
→ recommendation
→ approval/action
→ verification/learning

Connector UI must never claim “connected” without actual authorization/token state.
Secrets remain backend-only.

## Trust / security
- Backend/database is authoritative.
- Browser localStorage may cache/offline state but is never authoritative intelligence state.
- Enforce user/tenant isolation server-side.
- Do not trust client-supplied tenant identity.
- Do not expose connector credentials to the frontend.
- Use secure secret storage.
- Keep approval boundaries explicit.
- Record action proposals, approvals, executions and verification.
- Preserve provenance.
- Implement correct deletion/retention behavior.
- Never fabricate test results, connector states, health numbers or ZIO-EFFECT values.

## Historical implementation truth
The supplied 5.0 archive contains a significant historical regression: its frontend remained substantially local/browser-driven while 4.2 contained a stronger authenticated cloud bridge. Later live work evolved beyond the supplied 5.0 archive and introduced Workspace, Work Graph, Shadow/NEXUS, Source Fabric, memory retrieval, learning, realtime sync, security hardening and evidence-backed ZIO-EFFECT.

Therefore:
**Do not assume the highest version number is the canonical implementation.**
Inspect the actual current/live source and reconcile it with the historical archives.

## Required takeover process

### Phase 1 — Inventory
Inspect every file in the package.

### Phase 2 — Reconciliation
Create a capability matrix:
Capability | 4.0 | 4.2 | 5.0 | Current evidence | UI | Backend | Persisted | Governed | Tested | Production-ready | Keep/Fix/Replace

### Phase 3 — Canonical architecture
Establish one:
- identity/auth model
- database/state model
- memory model
- learning model
- graph model
- action/approval model
- source/connector model
- health/effect calculation

### Phase 4 — Trust Core
Prioritize:
1. authoritative persistence
2. identity/tenancy
3. provenance
4. action proposals
5. approvals
6. execution records
7. verification records
8. audit trail
9. deletion/retention
10. authoritative health/effect calculations

### Phase 5 — Intelligence
Complete the real NEXUS loop over workspace + graph + memory + learning + research.

### Phase 6 — External integration
Prove GitHub OAuth and sync end-to-end before cloning the adapter to other providers.

### Phase 7 — Verification
Run real automated E2E tests.

### Phase 8 — Human alpha
Give real people real goals. Measure whether ZIO makes them more capable.

## Non-negotiable release test
Prove with real persisted data:

Outcome created
→ work persisted
→ graph relationships persisted
→ NEXUS observes
→ relevant context retrieved
→ memory retrieved/governed
→ source evidence available
→ reasoning occurs
→ recommendation persisted
→ approval recorded
→ action executes
→ execution recorded
→ result verified
→ learning created
→ governed memory update
→ future recommendation improves

Use real authentication, real database state, real graph, real memory, real NEXUS, real approval, real verification and at least one real external source.

## What NOT to do
- Do not restart the project.
- Do not throw away older artifacts without comparing them.
- Do not treat 5.0 as canonical solely because it is newer.
- Do not add another dashboard just to show progress.
- Do not create six customer-facing products.
- Do not fake OAuth.
- Do not claim “production-ready” from clean deployment logs alone.
- Do not use localStorage as authoritative state.
- Do not make irreversible autonomous actions without the required approval.
- Do not turn memory into permanent truth.
- Do not build all five connectors before one is proven.

## Definition of done
ZIO is ready for serious production evaluation when the public experience, authenticated workspace, Astara, NEXUS, Memory Fabric, Learning Genome, Work Graph, Source Fabric and ZIO-EFFECT operate as one trustworthy system and the complete outcome-to-learning loop is independently tested.

The objective is not more code. It is **coherence, trust, intelligence and measurable usefulness**.
