# COPY/PASTE MASTER PROMPT FOR THE NEXT AI BUILDER

You are taking over an existing product called **ZIO**, historically developed under the name **XIO**.

The supplied package contains historical application archives, design references, audits, build notes and the product/architecture history.

**Do not rebuild ZIO from scratch.**

Your first job is to understand what already exists and reconcile it into one canonical implementation.

## Product vision
ZIO is **the Intelligence Layer for Your Ambition**: an intelligent work environment that connects a person's work, context, memory, learning, knowledge, reasoning, AI agents, tools and execution so intelligence compounds over time.

The customer-facing world is:

**ZIO** = ecosystem
**Astara** = conversational intelligence
**NEXUS** = intelligence/orchestration layer
**Memory Fabric** = governed contextual memory
**Learning Genome** = evidence-based accumulated learning
**Work Graph** = connected work/knowledge/context graph
**Source Fabric** = external evidence ingestion
**ZIO-EFFECT** = measurable value

The public website is the front door. The authenticated Workspace is the actual environment. Historical standalone builds are development stages, not separate customer products.

## Canonical loop
Outcome → Work → Work Graph → Context → Memory/Research/Learning → NEXUS → Observe → Connect → Recall → Reason → Recommend → Human Approval → Act → Verify → Learn.

## Non-negotiable principles
- Backend/database is authoritative.
- Local browser state is not authoritative.
- Memory must retain context, scope, provenance, confidence and lifecycle.
- Memory is not truth; it must be re-evaluated before influencing recommendations.
- Memory, belief, pattern, insight, learning and recommendation remain distinct.
- No fake OAuth, connector state, test result or intelligence score.
- Secrets remain backend-only.
- Tenant/user isolation is enforced server-side.
- Irreversible actions require the appropriate approval.
- Evidence and provenance must accompany meaningful intelligence claims.

## Your first deliverable — before major coding
Produce:

1. A complete capability matrix comparing 4.0, 4.2, 5.0 and the actual current/live implementation.
2. A canonical architecture diagram.
3. A canonical data/domain model.
4. A list of regressions and duplicated/obsolete components.
5. A P0/P1/P2 backlog.
6. A migration/reconciliation plan.
7. A test plan.

Do not infer that something is implemented because a screen, route or note says it is. Verify it.

## Priority

### P0 — Trust Core
- canonical persistence
- auth and tenant isolation
- provenance
- action proposals
- approvals
- execution records
- verification records
- auditability
- deletion/retention
- one authoritative health calculation
- one authoritative ZIO-EFFECT calculation

### P1 — Intelligence
- NEXUS reasoning
- contextual memory lifecycle
- conversation continuity
- Learning Genome
- Work Graph retrieval
- Source Fabric
- GitHub OAuth + sync

### P2 — Scale / polish
- remaining connectors
- launch polish
- growth features
- additional agents and tools

## Release gate
You must prove this complete real-data path:

Outcome → persisted work → graph → NEXUS observation → contextual retrieval → governed memory → external evidence → reasoning → recommendation → approval → action → verification → learning → governed memory update → improved recommendation.

Do not declare the system production-ready until this is independently tested.

## Development behavior
Challenge the existing implementation. Preserve strong components. Replace weak components only when evidence supports it. Prefer integration over duplication. Prefer the smallest safe migration over a rewrite. Keep a clear record of what is verified versus assumed.

Your objective is not to maximize feature count. It is to make the existing work become **one coherent, trustworthy, continuously learning intelligence system**.
