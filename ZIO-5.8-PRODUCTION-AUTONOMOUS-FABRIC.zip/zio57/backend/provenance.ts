export type Provenance={sourceType:string;sourceId:string;externalId?:string;connector?:string;retrievedAt:string;checksum?:string;confidence:number;scope:string};
export function provenanceHash(p:Provenance){ return `${p.sourceType}|${p.sourceId}|${p.externalId||''}|${p.connector||''}|${p.retrievedAt}|${p.checksum||''}|${p.scope}`; }
