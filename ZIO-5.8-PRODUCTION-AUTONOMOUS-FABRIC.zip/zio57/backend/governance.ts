export type Risk='low'|'medium'|'high'|'critical';
export type Decision='allow'|'review'|'deny';
export function actionDecision(risk:Risk, hasApproval:boolean, shadowPassed:boolean, capabilityAllowed:boolean):Decision{
  if(!capabilityAllowed)return 'deny';
  if(risk==='critical')return hasApproval&&shadowPassed?'review':'deny';
  if(risk==='high')return hasApproval&&shadowPassed?'allow':'review';
  if(!shadowPassed)return 'review';
  return hasApproval||risk==='low'?'allow':'review';
}
export function learningDecision(verified:boolean, confidence:number, contradictionFound:boolean){ if(contradictionFound)return 're_evaluate'; if(!verified)return 'hold'; return confidence>=0.85?'candidate':'hold'; }
