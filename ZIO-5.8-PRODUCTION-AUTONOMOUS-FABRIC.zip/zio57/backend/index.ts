import { router, json, error, requireAuth } from '@appdeploy/sdk';
import { buildAuthorizeUrl, isProvider, providerCapabilities, type Provider } from './connectors/registry';
import { hmacSha256, verifyHmac } from './connectors/security';
import { chunkText, scoreChunk } from './connectors/retrieval';
import { deriveLearningSignal } from './connectors/learning';
import { makeNonce, statePayload, stateExpired, validRedirectUri, encodeState, decodeState } from './connectors/oauth';
import { backoff, canRetry, idempotencyKey, leaseValid, type RetryPolicy } from './connectors/runtime';
import { hybridScore, freshnessScore, contradiction } from './connectors/semantic';
import { actionDecision, learningDecision, type Risk } from './governance';
import { provenanceHash, type Provenance } from './provenance';
import { readSecret, firstSecret, csvSecret } from './connectors/secrets';
import { encryptText, decryptText } from './connectors/crypto';
import { exchangeCode, refreshToken } from './connectors/provider-runtime';
import { db, ai } from '@appdeploy/sdk';

type MemoryStatus = 'active'|'pending'|'rejected';
type MemoryLifecycle = 'active'|'dormant'|'superseded'|'rejected';
type Verification = 'unverified'|'user_confirmed'|'system_verified';
type Memory = {
  userId:string; kind:string; content:string; confidence:number; status:MemoryStatus;
  createdAt:string; updatedAt:string; lastUsedAt?:string; useCount:number; source:string;
  sensitivity:'normal'|'sensitive'; scope?:string; provenance?:Record<string,unknown>;
  lifecycle?:MemoryLifecycle; verification?:Verification;
};
type Entitlement = {
  userId:string; plan:'free'|'pro'|'team'|'enterprise'; status:'active'|'past_due'|'canceled';
  ai:boolean; learning:boolean; auditExport:boolean; retentionDays:number; updatedAt:string;
};
type Audit = { userId:string; action:string; resource:string; resourceId?:string; metadata?:Record<string,unknown>; createdAt:string };
type Profile = { id?:string; userId:string; profile?:Record<string,unknown>; prefs?:Record<string,unknown>; updatedAt:string };
type GraphNode = { id?:string; userId:string; type:'person'|'project'|'task'|'decision'|'document'|'conversation'|'outcome'; title:string; data?:Record<string,unknown>; createdAt:string; updatedAt:string };
type GraphEdge = { id?:string; userId:string; fromId:string; toId:string; type:string; data?:Record<string,unknown>; createdAt:string };
type Outcome = { id?:string; userId:string; recommendationId?:string; action?:string; expected?:string; result?:string; verified:boolean; verificationNote?:string; createdAt:string; updatedAt:string };
type ShadowRun = { id?:string; userId:string; goal:string; assumptions?:Record<string,unknown>; predictions?:unknown; status:'simulated'|'failed'; createdAt:string };
type SourceDocument = { id?:string; userId:string; connectionId:string; externalId:string; title:string; content:string; url?:string; mimeType?:string; checksum:string; metadata?:Record<string,unknown>; indexedAt:string; updatedAt:string };
type SourceSync = { id?:string; userId:string; connectionId:string; status:'running'|'completed'|'failed'; received:number; indexed:number; failed:number; cursor?:string; error?:string; startedAt:string; completedAt?:string };
type ActionExecution = { id?:string; userId:string; actionIntentId:string; executor:string; status:'started'|'completed'|'failed'|'blocked'; externalRef?:string; result?:Record<string,unknown>; error?:string; createdAt:string; completedAt?:string };

const MAX = { message:10000, memory:1200, kind:80, source:120, eventType:80, conversationId:120, externalId:240, url:1000, mimeType:120, cursor:500, documentContent:50000 };
const DEFAULT_PREFS = { learning:true, askBeforeMemory:true };
const now = () => new Date().toISOString();
const clean = (value:unknown, max:number) => typeof value === 'string' ? value.trim().slice(0,max) : '';
const clamp01 = (n:unknown, fallback=0.7) => Number.isFinite(Number(n)) ? Math.max(0,Math.min(1,Number(n))) : fallback;
const bool = (v:unknown, fallback:boolean) => typeof v === 'boolean' ? v : fallback;

// Defensive request throttling. This is intentionally conservative; deploy-time infrastructure
// should still provide distributed rate limiting/WAF controls for multi-instance deployments.
const buckets = new Map<string,{window:number;count:number}>();
function rateLimit(userId:string, limit:number, windowMs:number){
  const t=Date.now(); const b=buckets.get(userId);
  if(!b || t-b.window>=windowMs){ buckets.set(userId,{window:t,count:1}); return true; }
  b.count += 1; return b.count <= limit;
}

async function getEntitlement(userId:string):Promise<Entitlement>{
  const rows = await db.list<Entitlement>('entitlements', { limit: 1000 });
  const found = rows.items.find(x => x.userId === userId);
  return found ?? { userId, plan:'free', status:'active', ai:true, learning:true, auditExport:false, retentionDays:90, updatedAt:now() };
}

async function getProfile(userId:string):Promise<Profile|undefined>{
  const rows = await db.list<Profile>('profiles',{limit:1000});
  return rows.items.find(x=>x.userId===userId);
}

async function audit(userId:string, action:string, resource:string, resourceId?:string, metadata?:Record<string,unknown>){
  await db.add('audit_events', [{ userId, action, resource, resourceId, metadata, createdAt:now() }]);
}

function authGuard(ctx:any){
  const userId=clean(ctx.user?.userId,200);
  return userId;
}

async function retrieveMemories(userId:string, query:string){
  const rows = await db.list<Memory>('memories', { limit: 1000 });
  const active = rows.items.filter(m => m.userId === userId && m.status === 'active' && m.lifecycle !== 'rejected');
  if (!active.length) return [];
  const shortlist = active.map(m => ({...m, score: lexicalScore(query, m.content)}))
    .filter(m => m.score > 0).sort((a,b)=>b.score-a.score).slice(0,12);
  if (!shortlist.length) return [];
  if (shortlist.length <= 3) return shortlist;
  try {
    const reranked = await ai.run({
      system:'Rank the supplied memories only by usefulness for the supplied query. Never invent ids. Return only an ordered ids array.',
      prompt:JSON.stringify({query, memories:shortlist.map(m=>({id:m.id,content:m.content}))}),
      thinkingMode:'FAST', maxSteps:2, maxTokens:500,
      tools:[{name:'emit_result',description:'Return ranked memory ids.',parameters:{type:'object',properties:{ids:{type:'array',items:{type:'string'}}},required:['ids'],additionalProperties:false}}]
    });
    const ids = (reranked.data as {ids?:string[]}|undefined)?.ids ?? [];
    const byId = new Map(shortlist.map(m=>[m.id,m]));
    const ranked=ids.map(id=>byId.get(id)).filter(Boolean).slice(0,8);
    return ranked.length ? ranked : shortlist.slice(0,8);
  } catch { return shortlist.slice(0,8); }
}

async function digest(value:string){
  const cryptoApi=(globalThis as any).crypto;
  if(cryptoApi?.subtle){ const buf=await cryptoApi.subtle.digest('SHA-256',new TextEncoder().encode(value)); return Array.from(new Uint8Array(buf)).map((b:number)=>b.toString(16).padStart(2,'0')).join(''); }
  return `sha256:${value.length}:${value.slice(0,32)}`;
}

async function retrieveSources(userId:string, query:string){
  const rows=await db.list<SourceDocument>('source_documents',{limit:2000});
  const ranked=rows.items.filter(d=>d.userId===userId).map(d=>({...d,score:lexicalScore(query,`${d.title} ${d.content}`)})).filter(d=>d.score>0).sort((a,b)=>b.score-a.score).slice(0,8);
  return ranked;
}

function lexicalScore(q:string, text:string){
  const a = new Set(q.toLowerCase().split(/\W+/).filter(x=>x.length>2));
  const b = new Set(text.toLowerCase().split(/\W+/).filter(x=>x.length>2));
  let n=0; for(const t of a) if(b.has(t)) n++;
  return n / Math.max(1,a.size);
}

function validConversationId(value:unknown){ return clean(value,MAX.conversationId) || 'default'; }
function object(value:unknown){ return value && typeof value==='object' && !Array.isArray(value) ? value as Record<string,unknown> : {}; }
function oneOf(value:unknown, allowed:string[], fallback:string){ const v=clean(value,80); return allowed.includes(v)?v:fallback; }
async function connectorSigningSecret(){ return readSecret('ZIO_CONNECTOR_SIGNING_SECRET'); }
async function connectorAuthSecret(){ return readSecret('ZIO_CONNECTOR_AUTH_SECRET'); }
async function connectorAuthorized(ctx:any){ const supplied=clean(ctx.headers?.['x-zio-connector-secret'],500); const expected=await connectorAuthSecret(); return Boolean(expected)&&supplied===expected; }
async function oauthRedirectAllowlist(){ return csvSecret('ZIO_OAUTH_REDIRECT_ALLOWLIST'); }
async function providerClient(provider:string){ return firstSecret(`ZIO_${provider.toUpperCase()}_CLIENT_ID`); }
async function providerClientSecret(provider:string){ return firstSecret(`ZIO_${provider.toUpperCase()}_CLIENT_SECRET`); }
async function tokenEncryptionKey(){ return readSecret('ZIO_TOKEN_ENCRYPTION_KEY'); }

export const handler = router({
  'GET /api/_healthcheck': [async () => json({ok:true,service:'ZIO intelligence core',version:'5.7-autonomous-intelligence-fabric'})],

  // Fail closed until a verified billing provider is connected.
  'POST /api/create-checkout-session': [requireAuth(), async () => error('Billing provider is not configured for this deployment',503)],

  'GET /api/xio/bootstrap': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    const ent=await getEntitlement(userId); const profile=await getProfile(userId);
    const mem=await db.list<Memory>('memories',{limit:1000});
    return json({user:{id:userId,name:ctx.user!.name,email:ctx.user!.email},entitlement:ent,
      memories:mem.items.filter(m=>m.userId===userId&&m.status==='active').slice(0,100),
      profile:profile?.profile??{name:ctx.user!.name||''},prefs:profile?.prefs??DEFAULT_PREFS});
  }],

  'GET /api/xio/state': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    const mem=await db.list<Memory>('memories',{limit:1000});
    const conv=await db.list<{userId:string;conversationId:string;role:string;content:string;createdAt:string}>('conversations',{limit:1000});
    const profile=await getProfile(userId);
    const ownMem=mem.items.filter(m=>m.userId===userId&&m.status==='active').map(m=>({
      id:m.id,text:m.content,category:m.kind,confidence:Math.round(m.confidence*100),source:m.source,
      confirmed:m.verification==='user_confirmed',active:true,created:Date.parse(m.createdAt)||Date.now(),lastConfirmed:Date.parse(m.updatedAt)||Date.now()
    }));
    const ownChat=conv.items.filter(c=>c.userId===userId).sort((a,b)=>Date.parse(a.createdAt)-Date.parse(b.createdAt)).slice(-100)
      .map(c=>({role:c.role==='assistant'?'xio':'user',text:c.content,at:Date.parse(c.createdAt)||Date.now()}));
    return json({user:{userId,email:ctx.user!.email,name:ctx.user!.name},memories:ownMem,chat:ownChat,
      profile:profile?.profile??{name:ctx.user!.name||''},prefs:profile?.prefs??DEFAULT_PREFS});
  }],

  'PUT /api/xio/profile': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    if(!rateLimit(userId,30,60000)) return error('Too many requests',429);
    const body=ctx.body as {profile?:Record<string,unknown>;prefs?:Record<string,unknown>};
    const existing=await getProfile(userId);
    const profile=body?.profile && typeof body.profile==='object' ? body.profile : existing?.profile ?? {name:ctx.user!.name||''};
    const incoming=body?.prefs && typeof body.prefs==='object' ? body.prefs : existing?.prefs ?? DEFAULT_PREFS;
    const prefs={...DEFAULT_PREFS,learning:bool(incoming.learning,true),askBeforeMemory:bool(incoming.askBeforeMemory,true)};
    const record={userId,profile,prefs,updatedAt:now()};
    if(existing?.id) await db.update('profiles',[{id:existing.id,record:{...existing,...record}}]);
    else await db.add('profiles',[record]);
    await audit(userId,'profile.update','profile');
    return json({ok:true,profile,prefs});
  }],

  'POST /api/xio/turn': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    if(!rateLimit(userId,60,60000)) return error('Rate limit exceeded',429);
    const body=ctx.body as {text?:string;conversationId?:string};
    const text=clean(body?.text,MAX.message); if(!text) return error('text is required',400);
    const conversationId=validConversationId(body?.conversationId);
    const ent=await getEntitlement(userId); if(!ent.ai||ent.status!=='active') return error('AI is not enabled for this account',403);
    const stored=await getProfile(userId);
    const profile=stored?.profile??{name:ctx.user!.name||''};
    const prefs={...DEFAULT_PREFS,...(stored?.prefs??{})};
    const memories=await retrieveMemories(userId,text);
    const sources=await retrieveSources(userId,text);
    const historyRows=await db.list<{userId:string;conversationId:string;role:string;content:string;createdAt:string}>('conversations',{limit:1000});
    const recent=historyRows.items.filter(x=>x.userId===userId&&x.conversationId===conversationId).sort((a,b)=>Date.parse(a.createdAt)-Date.parse(b.createdAt)).slice(-12);
    let response='I’m here. The intelligence service is temporarily unavailable, so I will not invent a memory.';
    let learning:{content:string;kind:string;confidence:number}|undefined;
    try {
      const aiResult=await ai.run({
        system:'You are ZIO. Use only relevant supplied memory. Never treat a recommendation, insight, belief, temporary request, or generated hypothesis as a durable memory. Return an optional learning candidate only when it is a stable user fact or preference explicitly supported by the conversation.',
        prompt:JSON.stringify({message:text,memories:memories.map(m=>({content:m!.content,kind:m!.kind,confidence:m!.confidence,scope:m!.scope})),sources:sources.map(s=>({title:s.title,content:s.content,url:s.url,score:s.score})),recent:recent.map(r=>({role:r.role,text:r.content})),profile}),
        thinkingMode:'FAST',maxSteps:4,maxTokens:1400,
        tools:[{name:'emit_result',description:'Return response and optional durable learning candidate.',parameters:{type:'object',properties:{response:{type:'string'},learning:{type:'object',properties:{content:{type:'string'},kind:{type:'string'},confidence:{type:'number'}},required:['content','kind','confidence'],additionalProperties:false}},required:['response'],additionalProperties:false}}]
      });
      const data=aiResult.data as {response?:string;learning?:{content:string;kind:string;confidence:number}}|undefined;
      response=clean(data?.response??aiResult.text,MAX.message)||response; learning=data?.learning;
    } catch(err){ console.error('ZIO response generation failed',err); }

    const ts=now();
    await db.add('conversations',[
      {userId,conversationId,role:'user',content:text,createdAt:ts},
      {userId,conversationId,role:'assistant',content:response,createdAt:now()}
    ]);

    const learningEnabled=prefs.learning!==false;
    const askBeforeMemory=prefs.askBeforeMemory!==false;
    let proposal:null|{id?:string;text:string;category:string;confidence:number;source:string}=null;
    if(learning&&ent.learning&&learningEnabled&&Number.isFinite(learning.confidence)&&learning.confidence>=0.78&&clean(learning.content,MAX.memory)){
      const timestamp=now();
      const [id]=await db.add('memories',[{
        userId,kind:clean(learning.kind,MAX.kind)||'preference',content:clean(learning.content,MAX.memory),
        confidence:clamp01(learning.confidence),status:askBeforeMemory?'pending':'active',createdAt:timestamp,updatedAt:timestamp,
        useCount:0,source:'ai_learning_loop',sensitivity:'normal',scope:'user',
        provenance:{source:'ai_learning_loop',conversationId,modelGenerated:true},lifecycle:'active',verification:askBeforeMemory?'unverified':'system_verified'
      }]);
      if(id) {
        await audit(userId,'memory.proposed','memory',id,{confidence:learning.confidence,requiresApproval:askBeforeMemory});
        proposal={id,text:clean(learning.content,MAX.memory),category:clean(learning.kind,MAX.kind)||'preference',confidence:Math.round(clamp01(learning.confidence)*100),source:'ai_learning_loop'};
      }
    }
    await audit(userId,'ai.respond','conversation',conversationId);
    return json({reply:response,proposals:proposal&&askBeforeMemory?[proposal]:[],autoMemories:proposal&&!askBeforeMemory?[proposal]:[],context:{memoryCount:memories.length,sourceCount:sources.length}});
  }],

  'POST /api/xio/memory/decision': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    const body=ctx.body as {id?:string;decision?:'accept'|'reject';memory?:{text?:string;category?:string;confidence?:number;source?:string}};
    if(body?.decision!=='accept'&&body?.decision!=='reject') return error('Decision must be accept or reject',400);
    if(body.id){
      const [m]=await db.get<Memory>('memories',[body.id]);
      if(!m||m.userId!==userId) return error('Memory not found',404);
      const accepted=body.decision==='accept';
      const next={...m,status:accepted?'active':'rejected',lifecycle:accepted?'active':'rejected',verification:accepted?'user_confirmed':'unverified',updatedAt:now()};
      await db.update('memories',[{id:body.id,record:next}]); await audit(userId,`memory.${body.decision}`,'memory',body.id);
      return json({ok:true,id:body.id,status:next.status});
    }
    const text=clean(body?.memory?.text,MAX.memory); if(!text) return error('Memory is required',400);
    if(body.decision==='reject'){ await audit(userId,'memory.reject','memory',undefined,{text:text.slice(0,200)}); return json({ok:true,status:'rejected'}); }
    const ts=now(); const [id]=await db.add('memories',[{userId,kind:clean(body.memory?.category,MAX.kind)||'preference',content:text,confidence:clamp01((body.memory?.confidence??72)/100),status:'active',createdAt:ts,updatedAt:ts,useCount:0,source:clean(body.memory?.source,MAX.source)||'user-confirmed',sensitivity:'normal',scope:'user',provenance:{source:'user-confirmed'},lifecycle:'active',verification:'user_confirmed'}]);
    await audit(userId,'memory.accept','memory',id ?? undefined); return json({ok:Boolean(id),id,status:'active'});
  }],

  'POST /api/xio/memory/confirm': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    const body=ctx.body as {id?:string;memory?:{text?:string;category?:string;confidence?:number;source?:string}};
    if(body.id){
      const [m]=await db.get<Memory>('memories',[body.id]); if(!m || m.userId!==userId) return error('Memory not found',404);
      const next={...m,status:'active',lifecycle:'active',verification:'user_confirmed',updatedAt:now()};
      await db.update('memories',[{id:body.id,record:next}]); await audit(userId,'memory.accept','memory',body.id);
      return json({ok:true,id:body.id,status:'active'});
    }
    const text=clean(body?.memory?.text,MAX.memory); if(!text) return error('Memory is required',400);
    const ts=now(); const [id]=await db.add('memories',[{userId,kind:clean(body.memory?.category,MAX.kind)||'preference',content:text,confidence:clamp01((body.memory?.confidence??72)/100),status:'active',createdAt:ts,updatedAt:ts,useCount:0,source:clean(body.memory?.source,MAX.source)||'user-confirmed',sensitivity:'normal',scope:'user',provenance:{source:'user-confirmed'},lifecycle:'active',verification:'user_confirmed'}]);
    await audit(userId,'memory.accept','memory',id ?? undefined); return json({ok:Boolean(id),id,status:'active'});
  }],

  'POST /api/xio/memory/reject': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    const body=ctx.body as {id?:string;memory?:{text?:string;category?:string}};
    if(body.id){
      const [m]=await db.get<Memory>('memories',[body.id]); if(!m || m.userId!==userId) return error('Memory not found',404);
      const next={...m,status:'rejected',lifecycle:'rejected',verification:'unverified',updatedAt:now()};
      await db.update('memories',[{id:body.id,record:next}]); await audit(userId,'memory.reject','memory',body.id);
      return json({ok:true,id:body.id,status:'rejected'});
    }
    const text=clean(body?.memory?.text,MAX.memory); if(!text) return error('Invalid memory',400);
    await audit(userId,'memory.reject','memory',undefined,{text:text.slice(0,200),category:body.memory?.category??'general'}); return json({ok:true,status:'rejected'});
  }],

  'POST /api/xio/memory/delete': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    const body=ctx.body as {id?:string}; const id=clean(body?.id,200); if(!id) return error('Memory id is required',400);
    const [m]=await db.get<Memory>('memories',[id]); if(!m || m.userId!==userId) return error('Memory not found',404);
    await db.update('memories',[{id,record:{...m,status:'rejected',lifecycle:'rejected',updatedAt:now()}}]);
    await audit(userId,'memory.delete','memory',id); return json({ok:true});
  }],

  'POST /api/xio/event': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    if(!rateLimit(userId,120,60000)) return error('Rate limit exceeded',429);
    const body=ctx.body as {type?:string;payload?:Record<string,unknown>}; const type=clean(body?.type,MAX.eventType);
    if(!type) return error('Invalid event',400);
    await audit(userId,'event',type,undefined,body?.payload&&typeof body.payload==='object'?body.payload:{}); return json({ok:true});
  }],

  'POST /api/xio/reset': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    // Security/compliance audit records are intentionally retained. Reset removes user-content
    // domains but records the reset event so the destructive action remains accountable.
    for(const table of ['memories','conversations','learning_signals','profiles']){
      const rows=await db.list<Record<string,unknown>>(table,{limit:1000});
      const ids=rows.items.filter(r=>r.userId===userId).map(r=>r.id).filter(Boolean) as string[];
      if(ids.length) await db.delete(table,ids);
    }
    await audit(userId,'data.reset','user_data'); return json({ok:true,deletedAt:now(),auditRetained:true});
  }],

  'GET /api/xio/entitlements': [requireAuth(), async (ctx:any) => { const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401); return json(await getEntitlement(userId)); }],


  'GET /api/xio/sources/search': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    if(!rateLimit(userId,60,60000)) return error('Rate limit exceeded',429);
    const q=clean(ctx.query?.q,MAX.message); if(!q) return error('q is required',400);
    const rows=await db.list<SourceDocument>('source_documents',{limit:2000});
    const own=rows.items.filter(x=>x.userId===userId);
    let ranked=own.map(d=>({...d,score:lexicalScore(q,`${d.title}\n${d.content}`)})).filter(d=>d.score>0).sort((a,b)=>b.score-a.score).slice(0,20);
    if(ranked.length>3){
      try{
        const rr=await ai.run({system:'Rank only the supplied source documents by relevance to the query. Return ordered ids only.',prompt:JSON.stringify({query:q,documents:ranked.map(d=>({id:d.id,title:d.title,content:d.content.slice(0,4000)}))}),thinkingMode:'FAST',maxSteps:2,maxTokens:500,tools:[{name:'emit_result',description:'Return ranked ids.',parameters:{type:'object',properties:{ids:{type:'array',items:{type:'string'}}},required:['ids'],additionalProperties:false}}]});
        const ids=(rr.data as any)?.ids??[]; const byId=new Map(ranked.map(d=>[d.id,d])); const reordered=ids.map((id:string)=>byId.get(id)).filter(Boolean).slice(0,12); if(reordered.length) ranked=reordered as any;
      }catch{}
    }
    await audit(userId,'source.search','source_document',undefined,{queryLength:q.length,resultCount:ranked.length});
    return json({query:q,documents:ranked.map(d=>({id:d.id,connectionId:d.connectionId,externalId:d.externalId,title:d.title,content:d.content,url:d.url,mimeType:d.mimeType,score:d.score,updatedAt:d.updatedAt}))});
  }],

  'GET /api/xio/context': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    if(!rateLimit(userId,60,60000)) return error('Rate limit exceeded',429);
    const q=clean(ctx.query?.q,MAX.message); if(!q) return error('q is required',400);
    const [memories,nodes,edges,sourceRows]=await Promise.all([
      retrieveMemories(userId,q),
      db.list<GraphNode>('work_graph_nodes',{limit:1000}),
      db.list<GraphEdge>('work_graph_edges',{limit:2000}),
      db.list<SourceDocument>('source_documents',{limit:2000})
    ]);
    const ownNodes=nodes.items.filter(n=>n.userId===userId);
    const nodeIds=new Set(ownNodes.map(n=>n.id));
    const ownEdges=edges.items.filter(e=>e.userId===userId&&nodeIds.has(e.fromId)&&nodeIds.has(e.toId));
    const graphMatches=ownNodes.map(n=>({...n,score:lexicalScore(q,`${n.title} ${JSON.stringify(n.data??{})}`)})).filter(n=>n.score>0).sort((a,b)=>b.score-a.score).slice(0,12);
    const sourceMatches=sourceRows.items.filter(d=>d.userId===userId).map(d=>({...d,score:lexicalScore(q,`${d.title} ${d.content}`)})).filter(d=>d.score>0).sort((a,b)=>b.score-a.score).slice(0,12);
    await audit(userId,'context.retrieve','context',undefined,{queryLength:q.length,memoryCount:memories.length,graphCount:graphMatches.length,sourceCount:sourceMatches.length});
    return json({query:q,memories,graph:{nodes:graphMatches,edges:ownEdges.filter(e=>graphMatches.some(n=>n.id===e.fromId)&&graphMatches.some(n=>n.id===e.toId))},sources:sourceMatches.map(d=>({id:d.id,connectionId:d.connectionId,title:d.title,content:d.content,url:d.url,score:d.score,updatedAt:d.updatedAt}))});
  }],

  'GET /api/xio/connectors/config-status': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    const names=await (await import('./connectors/secrets')).hasSecret('ZIO_CONNECTOR_AUTH_SECRET');
    const signing=await (await import('./connectors/secrets')).hasSecret('ZIO_CONNECTOR_SIGNING_SECRET');
    const encryption=await (await import('./connectors/secrets')).hasSecret('ZIO_TOKEN_ENCRYPTION_KEY');
    const redirects=(await oauthRedirectAllowlist()).length>0;
    const providers=['google','microsoft','github','notion','slack','linear']; const providerStatus:Record<string,boolean>={}; for(const p of providers) providerStatus[p]=Boolean((await providerClient(p))?.value&&(await providerClientSecret(p))?.value);
    await audit(userId,'connector.config_status','connector_runtime'); return json({connectorAuthConfigured:names,signingConfigured:signing,tokenEncryptionConfigured:encryption,redirectAllowlistConfigured:redirects,providers:providerStatus});
  }],

  'GET /api/xio/connectors/catalog': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    return json({providers:Object.entries(providerCapabilities).map(([provider,capabilities])=>({provider,capabilities}))});
  }],

  'POST /api/xio/connectors/oauth-url': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    const body=object(ctx.body); const provider=clean(body.provider,80); const redirectUri=clean(body.redirectUri,1000);
    if(!isProvider(provider)||provider==='custom') return error('Unsupported OAuth provider',400);
    const allowlist=await oauthRedirectAllowlist(); if(!validRedirectUri(redirectUri,allowlist)) return error('Redirect URI is not allowlisted',400);
    const client=await providerClient(provider); const signingSecret=await connectorSigningSecret(); if(!client?.value||!signingSecret) return error('OAuth provider is not configured',503);
    const nonce=makeNonce(); const expiresAt=new Date(Date.now()+10*60*1000).toISOString(); const payload=statePayload({nonce,userId,provider,redirectUri,expiresAt});
    const signature=await hmacSha256(signingSecret,payload); const state=encodeState(payload,signature);
    const [id]=await db.add('oauth_states',[{userId,provider,nonce,redirectUri,expiresAt,consumedAt:undefined}]); if(!id) return error('Unable to create OAuth state',500);
    const scopes=Array.isArray(body.scopes)?body.scopes.map(x=>clean(x,120)).filter(Boolean).slice(0,30):[];
    await audit(userId,'oauth.state.create','oauth_state',id,{provider,expiresAt});
    return json({provider,authorizeUrl:buildAuthorizeUrl(provider,state,client.value,redirectUri,scopes),stateExpiresInSeconds:600,credentialsStayServerSide:true});
  }],

  'POST /api/xio/connectors/webhook': [async (ctx:any) => {
    if(!(await connectorAuthorized(ctx))) return error('Connector authentication failed',401);
    const signature=clean(ctx.headers?.['x-zio-signature'],200); const payload=JSON.stringify(ctx.body??{}); const secret=await connectorSigningSecret();
    if(!signature||!(await verifyHmac(secret,payload,signature))) return error('Invalid connector signature',401);
    const body=object(ctx.body); const eventId=clean(body.eventId,240); const userId=clean(body.userId,200); const type=clean(body.type,120);
    if(!eventId||!userId||!type) return error('eventId, userId and type are required',400);
    const existing=await db.list<any>('connector_events',{limit:2000}); if(existing.items.some(e=>e.eventId===eventId)) return json({ok:true,duplicate:true,eventId});
    await db.add('connector_events',[{eventId,userId,type,payload:object(body.payload),receivedAt:now()}]);
    await audit(userId,'connector.webhook.received','connector_event',eventId,{type});
    return json({ok:true,duplicate:false,eventId});
  }],

  'POST /api/xio/connectors/ingest': [async (ctx:any) => {
    if(!(await connectorAuthorized(ctx))) return error('Connector authentication failed',401);
    const body=object(ctx.body); const userId=clean(body.userId,200); const connectionId=clean(body.connectionId,200);
    if(!userId||!connectionId||!Array.isArray(body.documents)) return error('userId, connectionId and documents are required',400);
    const [connection]=await db.get<any>('source_connections',[connectionId]); if(!connection||connection.userId!==userId) return error('Connection not found',404);
    const docs=body.documents.slice(0,500); let indexed=0; let failed=0; let chunks=0;
    for(const raw of docs){ const d=object(raw); const externalId=clean(d.externalId,MAX.externalId); const title=clean(d.title,MAX.message); const content=clean(d.content,MAX.documentContent); if(!externalId||!title||!content){failed++;continue;}
      const checksum=await digest(`${externalId}\n${title}\n${content}`); const existing=await db.list<SourceDocument>('source_documents',{limit:2000}); const prior=existing.items.find(x=>x.userId===userId&&x.connectionId===connectionId&&x.externalId===externalId);
      const record={userId,connectionId,externalId,title,content,url:clean(d.url,MAX.url)||undefined,mimeType:clean(d.mimeType,MAX.mimeType)||undefined,checksum,metadata:object(d.metadata),indexedAt:now(),updatedAt:now()};
      try { if(prior?.id) await db.update('source_documents',[{id:prior.id,record:{...prior,...record}}]); else await db.add('source_documents',[record]); chunks += chunkText(prior?.id??externalId,content).length; indexed++; } catch { failed++; }
    }
    await db.add('connector_events',[{eventId:`ingest:${userId}:${connectionId}:${Date.now()}`,userId,type:'documents.ingested',payload:{received:docs.length,indexed,failed,chunks},receivedAt:now()}]);
    return json({ok:failed===0,indexed,failed,chunks});
  }],

  'POST /api/xio/connectors/action-result': [async (ctx:any) => {
    if(!(await connectorAuthorized(ctx))) return error('Connector authentication failed',401);
    const body=object(ctx.body); const executionId=clean(body.executionId,200); const userId=clean(body.userId,200); if(!executionId||!userId) return error('executionId and userId are required',400);
    const [execution]=await db.get<any>('action_executions',[executionId]); if(!execution||execution.userId!==userId) return error('Execution not found',404); if(execution.status!=='started') return error('Execution already finalized',409);
    const status=oneOf(body.status,['completed','failed','blocked'],'failed'); const result=object(body.result); const ts=now();
    await db.update('action_executions',[{id:executionId,record:{...execution,status,result,error:clean(body.error,MAX.message)||undefined,externalRef:clean(body.externalRef,200)||undefined,completedAt:ts}}]);
    const signal=deriveLearningSignal({kind:'action_result',confidence:status==='completed'?0.8:0.95,evidence:[`connector:${clean(body.externalRef,200)||'internal'}`],sourceIds:[execution.actionIntentId]});
    await db.add('learning_signals',[{userId,source:'connector',signal,createdAt:ts}]); await audit(userId,'connector.action_result','action_execution',executionId,{status});
    return json({ok:true,executionId,status,learningSignal:signal});
  }],

  'POST /api/xio/sources/connect': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    if(!rateLimit(userId,20,60000)) return error('Rate limit exceeded',429);
    const body=object(ctx.body); const provider=clean(body.provider,80); if(!provider) return error('provider is required',400);
    const allowed=['google','microsoft','github','notion','slack','linear','custom'];
    if(!allowed.includes(provider)) return error('Unsupported source provider',400);
    const scopes=Array.isArray(body.scopes)?body.scopes.map(x=>clean(x,120)).filter(Boolean).slice(0,30):[];
    const ts=now();
    const [id]=await db.add('source_connections',[{userId,provider,status:'pending',scopes,metadata:{oauthStateRequired:true,credentialsStoredServerSide:true},createdAt:ts,updatedAt:ts}]);
    await audit(userId,'source.connect.start','source_connection',id ?? undefined,{provider,scopeCount:scopes.length});
    return json({ok:Boolean(id),id,status:'pending',next:'oauth_provider_redirect',credentialsMustRemainServerSide:true});
  }],

  'POST /api/xio/sources/sync': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    if(!rateLimit(userId,10,60000)) return error('Rate limit exceeded',429);
    const body=object(ctx.body); const connectionId=clean(body.connectionId,200); if(!connectionId) return error('connectionId is required',400);
    const [connection]=await db.get<any>('source_connections',[connectionId]);
    if(!connection||connection.userId!==userId) return error('Source connection not found',404);
    if(connection.status!=='connected') return error('Source connection is not connected',409);
    const documents=Array.isArray(body.documents)?body.documents.slice(0,500):[];
    const cursor=clean(body.cursor,MAX.cursor)||undefined; const syncId=(await db.add('source_syncs',[{userId,connectionId,status:'running',received:documents.length,indexed:0,failed:0,cursor,startedAt:now()}]))[0];
    let indexed=0, failed=0;
    for(const raw of documents){
      const d=object(raw); const externalId=clean(d.externalId,MAX.externalId); const title=clean(d.title,MAX.message); const content=clean(d.content,MAX.documentContent);
      if(!externalId||!title||!content){ failed++; continue; }
      const checksum=await digest(`${externalId}\n${title}\n${content}`);
      const existing=await db.list<SourceDocument>('source_documents',{limit:1000});
      const prior=existing.items.find(x=>x.userId===userId&&x.connectionId===connectionId&&x.externalId===externalId);
      const record={userId,connectionId,externalId,title,content,url:clean(d.url,MAX.url)||undefined,mimeType:clean(d.mimeType,MAX.mimeType)||undefined,checksum,metadata:object(d.metadata),indexedAt:now(),updatedAt:now()};
      try {
        let documentId=prior?.id as string|undefined;
        if(documentId) await db.update('source_documents',[{id:documentId,record:{...prior,...record}}]);
        else { const [created]=await db.add('source_documents',[record]); documentId=created; }
        const generated=chunkText(documentId??externalId,content);
        if(generated.length){
          const priorChunks=await db.list<any>('source_chunks',{limit:5000});
          const owned=priorChunks.items.filter(x=>x.userId===userId&&x.documentId===documentId);
          const fresh=generated.filter(c=>!owned.some(x=>Number(x.chunkIndex)===c.index));
          if(fresh.length) await db.add('source_chunks',fresh.map(c=>({id:c.id,userId,documentId,chunkIndex:c.index,content:c.text,tokenEstimate:c.tokenEstimate,createdAt:now()})));
        }
        indexed++;
      } catch { failed++; }
    }
    const status=failed && indexed===0?'failed':'completed';
    if(syncId) await db.update('source_syncs',[{id:syncId,record:{userId,connectionId,status,received:documents.length,indexed,failed,cursor,startedAt:now(),completedAt:now()}}]);
    await audit(userId,'source.sync','source_connection',connectionId,{received:documents.length,indexed,failed});
    return json({ok:status==='completed',syncId,status,received:documents.length,indexed,failed,cursor});
  }],

  'POST /api/xio/sources/connection-status': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    const body=object(ctx.body); const id=clean(body.id,200); const status=oneOf(body.status,['pending','connected','revoked','error'],'pending');
    if(!id) return error('id is required',400);
    const [connection]=await db.get<any>('source_connections',[id]); if(!connection||connection.userId!==userId) return error('Source connection not found',404);
    await db.update('source_connections',[{id,record:{...connection,status,externalAccountId:clean(body.externalAccountId,200)||connection.externalAccountId,updatedAt:now()}}]);
    await audit(userId,'source.connection_status','source_connection',id,{status});
    return json({ok:true,id,status});
  }],

  'GET /api/xio/sources': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    const rows=await db.list<any>('source_connections',{limit:500});
    return json({connections:rows.items.filter(x=>x.userId===userId).map(x=>({id:x.id,provider:x.provider,status:x.status,scopes:x.scopes,externalAccountId:x.externalAccountId,createdAt:x.createdAt,updatedAt:x.updatedAt}))});
  }],

  'POST /api/xio/actions/propose': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    if(!rateLimit(userId,30,60000)) return error('Rate limit exceeded',429);
    const body=object(ctx.body); const action=clean(body.action,MAX.message); if(!action) return error('action is required',400);
    const risk=oneOf(body.risk,['low','medium','high','critical'],'medium'); const ts=now();
    const [id]=await db.add('action_intents',[{userId,action,target:clean(body.target,MAX.message)||undefined,parameters:object(body.parameters),risk,status:'proposed',shadowRunId:clean(body.shadowRunId,200)||undefined,createdAt:ts,updatedAt:ts}]);
    await audit(userId,'action.propose','action_intent',id ?? undefined,{risk});
    return json({ok:Boolean(id),id,status:'proposed',requiresExplicitApproval:true,execution:false});
  }],

  'POST /api/xio/actions/approve': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    const body=object(ctx.body); const id=clean(body.id,200); if(!id) return error('Action id is required',400);
    const [a]=await db.get<any>('action_intents',[id]); if(!a||a.userId!==userId) return error('Action not found',404);
    if(a.status!=='proposed') return error('Only proposed actions can be approved',409);
    if(a.risk==='critical'||a.risk==='high') return error('High-impact actions require an external policy approval workflow',403);
    const ts=now(); await db.update('action_intents',[{id,record:{...a,status:'approved',approvedAt:ts,updatedAt:ts}}]);
    await audit(userId,'action.approve','action_intent',id,{risk:a.risk});
    return json({ok:true,id,status:'approved',execution:false,executionRequiresDedicatedProvider:true});
  }],

  'POST /api/xio/actions/execute': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    if(!rateLimit(userId,10,60000)) return error('Rate limit exceeded',429);
    const body=object(ctx.body); const id=clean(body.id,200); if(!id) return error('Action id is required',400);
    const [a]=await db.get<any>('action_intents',[id]); if(!a||a.userId!==userId) return error('Action not found',404);
    if(a.status!=='approved') return error('Only approved actions can execute',409);
    if(a.risk==='critical'||a.risk==='high') return error('High-impact actions require external policy approval',403);
    const executor=clean(body.executor,120); if(!executor) return error('executor is required',400);
    const allowedExecutors=['connector-service']; if(!allowedExecutors.includes(executor)) return error('Executor is not registered',403);
    const requestKey=clean(body.requestKey,200); if(!requestKey) return error('requestKey is required',400);
    const key=idempotencyKey(userId,id,requestKey); const existing=await db.list<any>('action_idempotency',{limit:1000}); const prior=existing.items.find(x=>x.userId===userId&&x.idempotencyKey===key); if(prior) return json({ok:true,duplicate:true,executionId:prior.executionId,status:'started',idempotencyKey:key});
    const [executionId]=await db.add('action_executions',[{userId,actionIntentId:id,executor,status:'started',createdAt:now(),idempotencyKey:key}]); if(!executionId) return error('Unable to create action execution',500);
    const [idemId]=await db.add('action_idempotency',[{userId,idempotencyKey:key,executionId,createdAt:now()}]); if(!idemId){ await db.delete('action_executions',[executionId]); return error('Unable to establish idempotency record',500); }
    // The core never executes arbitrary network calls. A registered connector service must own external side effects.
    await audit(userId,'action.execute.dispatch','action_execution',executionId,{actionIntentId:id,executor,idempotencyKey:key});
    return json({ok:true,duplicate:false,executionId,status:'started',dispatch:{executor,actionIntentId:id},sideEffectPerformed:false,connectorMustAcknowledge:true,idempotencyKey:key});
  }],

  'POST /api/xio/actions/execution-result': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    const body=object(ctx.body); const id=clean(body.executionId,200); const status=oneOf(body.status,['completed','failed','blocked'],'failed');
    if(!id) return error('executionId is required',400);
    const [execution]=await db.get<any>('action_executions',[id]); if(!execution||execution.userId!==userId) return error('Execution not found',404);
    if(execution.status!=='started') return error('Execution is already finalized',409);
    const ts=now(); await db.update('action_executions',[{id,record:{...execution,status,result:object(body.result),error:clean(body.error,MAX.message)||undefined,externalRef:clean(body.externalRef,200)||undefined,completedAt:ts}}]);
    await audit(userId,'action.execute.result','action_execution',id,{status});
    return json({ok:true,id,status});
  }],

  'POST /api/xio/outcomes/verify': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    const body=object(ctx.body); const outcomeId=clean(body.outcomeId,200); const verdict=oneOf(body.verdict,['verified','rejected','inconclusive'],'inconclusive');
    const verifier=clean(body.verifier,120)||'user'; if(!outcomeId) return error('outcomeId is required',400);
    const [outcome]=await db.get<any>('outcomes',[outcomeId]); if(!outcome||outcome.userId!==userId) return error('Outcome not found',404);
    const [id]=await db.add('outcome_verifications',[{userId,outcomeId,verifier,evidence:object(body.evidence),verdict,createdAt:now()}]);
    const verified=verdict==='verified';
    await db.update('outcomes',[{id:outcomeId,record:{...outcome,verified,verificationNote:clean(body.note,MAX.message)||outcome.verificationNote,updatedAt:now()}}]);
    await audit(userId,'outcome.verify','outcome',outcomeId,{verdict,verifier});
    return json({ok:Boolean(id),verificationId:id,outcomeId,verdict,verified});
  }],

  'POST /api/xio/telemetry': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    if(!rateLimit(userId,300,60000)) return error('Rate limit exceeded',429);
    const body=object(ctx.body); const traceId=clean(body.traceId,120); const event=clean(body.event,120);
    if(!traceId||!event) return error('traceId and event are required',400);
    const latency=Math.max(0,Math.min(3600000,Number(body.latencyMs)||0)); const success=bool(body.success,true);
    await db.add('observability_events',[{userId,traceId,event,latencyMs:latency,success,metadata:object(body.metadata),createdAt:now()}]);
    return json({ok:true});
  }],

  'GET /api/xio/telemetry/summary': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    const rows=await db.list<any>('observability_events',{limit:2000}); const own=rows.items.filter(x=>x.userId===userId);
    const total=own.length, failures=own.filter(x=>x.success===false).length;
    const latencies=own.map(x=>Number(x.latencyMs)||0).sort((a,b)=>a-b); const p95=latencies.length?latencies[Math.min(latencies.length-1,Math.ceil(latencies.length*.95)-1)]:0;
    return json({total,failures,errorRate:total?failures/total:0,p95LatencyMs:p95});
  }],

  'POST /api/xio/graph/nodes': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    if(!rateLimit(userId,60,60000)) return error('Rate limit exceeded',429);
    const body=object(ctx.body); const title=clean(body.title,MAX.message); const type=oneOf(body.type,['person','project','task','decision','document','conversation','outcome'],'task');
    if(!title) return error('title is required',400);
    const ts=now(); const [id]=await db.add('work_graph_nodes',[{userId,type,title,data:object(body.data),createdAt:ts,updatedAt:ts}]);
    await audit(userId,'graph.node.create','work_graph_node',id ?? undefined,{type}); return json({ok:Boolean(id),id});
  }],

  'POST /api/xio/graph/edges': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    const body=object(ctx.body); const fromId=clean(body.fromId,200), toId=clean(body.toId,200), type=clean(body.type,100);
    if(!fromId||!toId||!type) return error('fromId, toId and type are required',400);
    const rows=await db.list<GraphNode>('work_graph_nodes',{limit:1000}); const owned=new Set(rows.items.filter(n=>n.userId===userId).map(n=>n.id));
    if(!owned.has(fromId)||!owned.has(toId)) return error('Graph node not found',404);
    const [id]=await db.add('work_graph_edges',[{userId,fromId,toId,type,data:object(body.data),createdAt:now()}]);
    await audit(userId,'graph.edge.create','work_graph_edge',id ?? undefined,{type}); return json({ok:Boolean(id),id});
  }],

  'GET /api/xio/graph': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    const [nodes,edges]=await Promise.all([db.list<GraphNode>('work_graph_nodes',{limit:1000}),db.list<GraphEdge>('work_graph_edges',{limit:2000})]);
    const ownNodes=nodes.items.filter(n=>n.userId===userId); const ids=new Set(ownNodes.map(n=>n.id));
    return json({nodes:ownNodes,edges:edges.items.filter(e=>e.userId===userId&&ids.has(e.fromId)&&ids.has(e.toId))});
  }],

  'POST /api/xio/shadow/simulate': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    if(!rateLimit(userId,20,60000)) return error('Rate limit exceeded',429);
    const body=object(ctx.body); const goal=clean(body.goal,MAX.message); if(!goal) return error('goal is required',400);
    let predictions:unknown={summary:'Simulation unavailable'}; let status:'simulated'|'failed'='failed';
    try {
      const result=await ai.run({system:'You are ZIO Shadow. Simulate consequences without executing actions. Distinguish facts, assumptions and predictions. Never claim an external action occurred. Return structured predictions with risks, benefits, uncertainties and reversible next steps.',prompt:JSON.stringify({goal,assumptions:object(body.assumptions)}),thinkingMode:'FAST',maxSteps:4,maxTokens:1200,tools:[{name:'emit_result',description:'Return a safe simulation.',parameters:{type:'object',properties:{summary:{type:'string'},risks:{type:'array',items:{type:'string'}},benefits:{type:'array',items:{type:'string'}},uncertainties:{type:'array',items:{type:'string'}},nextSteps:{type:'array',items:{type:'string'}}},required:['summary','risks','benefits','uncertainties','nextSteps'],additionalProperties:false}}]});
      predictions=result.data ?? {summary:clean(result.text,MAX.message)}; status='simulated';
    } catch(err){ console.error('Shadow simulation failed',err); }
    const [id]=await db.add('shadow_runs',[{userId,goal,assumptions:object(body.assumptions),predictions,status,createdAt:now()}]);
    await audit(userId,'shadow.simulate','shadow_run',id ?? undefined,{status}); return json({ok:status==='simulated',id,status,predictions});
  }],

  'POST /api/xio/outcomes': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    const body=object(ctx.body); const action=clean(body.action,MAX.message); if(!action) return error('action is required',400);
    const expected=clean(body.expected,MAX.message); const result=clean(body.result,MAX.message);
    const verified=bool(body.verified,false); const [id]=await db.add('outcomes',[{userId,recommendationId:clean(body.recommendationId,200)||undefined,action,expected,result,verified,verificationNote:clean(body.verificationNote,MAX.message)||undefined,createdAt:now(),updatedAt:now()}]);
    await audit(userId,verified?'outcome.verified':'outcome.recorded','outcome',id ?? undefined); return json({ok:Boolean(id),id,verified});
  }],

  'POST /api/xio/memory/reactivate': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    const body=object(ctx.body); const id=clean(body.id,200); if(!id) return error('Memory id is required',400);
    const [m]=await db.get<Memory>('memories',[id]); if(!m||m.userId!==userId) return error('Memory not found',404);
    if(m.lifecycle!=='dormant') return error('Only dormant memories can be reactivated',409);
    const next={...m,lifecycle:'active' as MemoryLifecycle,verification:'unverified' as Verification,updatedAt:now()};
    await db.update('memories',[{id,record:next}]); await audit(userId,'memory.reactivate','memory',id); return json({ok:true,id,status:next.status,lifecycle:next.lifecycle,requiresReevaluation:true});
  }],

  'POST /api/xio/oauth/state': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401); const body=object(ctx.body); const provider=clean(body.provider,80); const redirectUri=clean(body.redirectUri,1000);
    if(!isProvider(provider)||provider==='custom') return error('Unsupported provider',400); const allowlist=await oauthRedirectAllowlist(); if(!validRedirectUri(redirectUri,allowlist)) return error('Redirect URI is not allowlisted',400);
    const nonce=makeNonce(); const expiresAt=new Date(Date.now()+10*60*1000).toISOString(); const payload=statePayload({nonce,userId,provider,redirectUri,expiresAt}); const secret=await connectorSigningSecret(); if(!secret) return error('Connector signing secret is not configured',503);
    const signature=await hmacSha256(secret,payload); const state=encodeState(payload,signature); const [id]=await db.add('oauth_states',[{userId,provider,nonce,redirectUri,expiresAt,consumedAt:undefined}]);
    await audit(userId,'oauth.state.create','oauth_state',id??undefined,{provider,expiresAt}); return json({ok:Boolean(id),state,nonce,expiresAt});
  }],

  'POST /api/xio/oauth/consume': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    const body=object(ctx.body); const nonce=clean(body.nonce,200); const provider=clean(body.provider,80); const redirectUri=clean(body.redirectUri,1000);
    if(!nonce||!isProvider(provider)||!redirectUri) return error('nonce, provider and redirectUri are required',400);
    const rows=await db.list<any>('oauth_states',{limit:1000}); const state=rows.items.find(x=>x.userId===userId&&x.nonce===nonce&&x.provider===provider&&x.redirectUri===redirectUri);
    if(!state) return error('OAuth state not found',404); if(state.consumedAt) return error('OAuth state already consumed',409); if(stateExpired(state)) return error('OAuth state expired',410);
    await db.update('oauth_states',[{id:state.id,record:{...state,consumedAt:now()}}]); await audit(userId,'oauth.state.consume','oauth_state',state.id,{provider});
    return json({ok:true,nonce,provider,redirectUri});
  }],

  'GET /api/xio/oauth/callback': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401); const stateText=clean(ctx.query?.state,5000); const code=clean(ctx.query?.code,5000); if(!stateText||!code) return error('state and code are required',400);
    const signingSecret=await connectorSigningSecret(); if(!signingSecret) return error('Connector signing secret is not configured',503);
    let decoded:{payload:string;signature:string}; try{ decoded=decodeState(stateText); }catch{return error('Invalid OAuth state',400);} if(!(await verifyHmac(signingSecret,decoded.payload,decoded.signature))) return error('Invalid OAuth state',401);
    let state:Record<string,string>; try{ state=JSON.parse(decoded.payload) as Record<string,string>; }catch{return error('Invalid OAuth state',400);} if(state.userId!==userId||stateExpired(state as any)) return error('OAuth state expired or mismatched',410);
    const rows=await db.list<any>('oauth_states',{limit:1000}); const stored=rows.items.find(x=>x.userId===userId&&x.nonce===state.nonce&&x.provider===state.provider&&x.redirectUri===state.redirectUri); if(!stored)return error('OAuth state not found',404); if(stored.consumedAt)return error('OAuth state already consumed',409);
    const client=await providerClient(state.provider); const clientSecret=await providerClientSecret(state.provider); const encryptionKey=await tokenEncryptionKey(); if(!client?.value||!clientSecret?.value||!encryptionKey) return error('OAuth provider token storage is not configured',503);
    try{
      const tokens=await exchangeCode(state.provider,code,state.redirectUri,client.value,clientSecret.value); const ciphertext=await encryptText(JSON.stringify(tokens),encryptionKey); const [tokenId]=await db.add('connector_tokens',[{userId,provider:state.provider,encrypted:ciphertext,keyVersion:'v1',scope:tokens.scope,expiresAt:tokens.expiresIn?new Date(Date.now()+tokens.expiresIn*1000).toISOString():undefined,createdAt:now(),updatedAt:now()}]);
      const connections=await db.list<any>('source_connections',{limit:500}); const pending=connections.items.filter(x=>x.userId===userId&&x.provider===state.provider&&x.status==='pending').sort((a,b)=>Date.parse(b.createdAt)-Date.parse(a.createdAt))[0]; if(pending?.id) await db.update('source_connections',[{id:pending.id,record:{...pending,status:'connected',updatedAt:now()}}]);
      await db.update('oauth_states',[{id:stored.id,record:{...stored,consumedAt:now()}}]); await audit(userId,'oauth.callback.success','connector_token',tokenId??undefined,{provider:state.provider}); return json({ok:Boolean(tokenId),provider:state.provider,connected:true,connectionId:pending?.id??null});
    }catch(err){ await audit(userId,'oauth.callback.failed','oauth_state',stored.id,{provider:state.provider,error:err instanceof Error?err.message:'token_exchange_failed'}); return error('OAuth provider exchange failed',502); }
  }],

  'POST /api/xio/connectors/token-refresh': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401); const body=object(ctx.body); const provider=clean(body.provider,80); if(!isProvider(provider)||provider==='custom') return error('Unsupported provider',400);
    const encryptionKey=await tokenEncryptionKey(); const client=await providerClient(provider); const clientSecret=await providerClientSecret(provider); if(!encryptionKey||!client?.value||!clientSecret?.value) return error('Provider token configuration is incomplete',503);
    const rows=await db.list<any>('connector_tokens',{limit:500}); const token=rows.items.filter(x=>x.userId===userId&&x.provider===provider).sort((a,b)=>Date.parse(b.updatedAt)-Date.parse(a.updatedAt))[0]; if(!token)return error('Connector token not found',404);
    try{ const parsed=JSON.parse(await decryptText(token.encrypted,encryptionKey)) as {refreshToken?:string;accessToken?:string}; if(!parsed.refreshToken)return error('Connector does not provide a refresh token',409); const fresh=await refreshToken(provider,parsed.refreshToken,client.value,clientSecret.value); const ciphertext=await encryptText(JSON.stringify(fresh),encryptionKey); await db.update('connector_tokens',[{id:token.id,record:{...token,encrypted:ciphertext,keyVersion:'v1',scope:fresh.scope??token.scope,expiresAt:fresh.expiresIn?new Date(Date.now()+fresh.expiresIn*1000).toISOString():token.expiresAt,updatedAt:now()}}]); await audit(userId,'oauth.token.refresh','connector_token',token.id,{provider}); return json({ok:true,provider,refreshed:true,expiresAt:fresh.expiresIn?new Date(Date.now()+fresh.expiresIn*1000).toISOString():token.expiresAt}); }
    catch(err){ await audit(userId,'oauth.token.refresh.failed','connector_token',token.id,{provider,error:err instanceof Error?err.message:'refresh_failed'}); return error('Connector token refresh failed',502); }
  }],

  'GET /api/xio/semantic-search': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    const q=clean(ctx.query?.q,MAX.message); if(!q) return error('q is required',400);
    const docs=await db.list<any>('source_documents',{limit:2000}); const chunks=await db.list<any>('source_chunks',{limit:5000});
    const ownDocs=docs.items.filter(x=>x.userId===userId); const docMap=new Map(ownDocs.map(x=>[x.id,x]));
    const candidates=chunks.items.filter(x=>x.userId===userId&&docMap.has(x.documentId)).map(x=>{
      const d=docMap.get(x.documentId); const lexical=scoreChunk(q,x.content); const freshness=freshnessScore(d.updatedAt||d.indexedAt||now()); const authority=Number(d.metadata?.authority??0.7); const semantic=Number(x.semanticScore??0); return {...x,title:d.title,url:d.url,lexical,semantic,authority,freshness,score:hybridScore(lexical,semantic,authority,freshness)};
    }).sort((a,b)=>b.score-a.score).slice(0,20);
    await audit(userId,'retrieval.semantic_search','source_chunks',undefined,{queryLength:q.length,count:candidates.length});
    return json({query:q,results:candidates,mode:'hybrid',semanticProviderConfigured:candidates.some(x=>x.semantic>0)});
  }],

  'POST /api/xio/provenance': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401); const body=object(ctx.body);
    const artifactType=clean(body.artifactType,80), artifactId=clean(body.artifactId,200); if(!artifactType||!artifactId) return error('artifactType and artifactId are required',400);
    const provenance=object(body.provenance) as Provenance; const normalized={...provenance,sourceType:clean(provenance.sourceType,80),sourceId:clean(provenance.sourceId,200),connector:clean(provenance.connector,80)||undefined,retrievedAt:clean(provenance.retrievedAt,80)||now(),scope:clean(provenance.scope,80)||'user',confidence:clamp01(provenance.confidence)};
    const hash=await digest(provenanceHash(normalized)); const [id]=await db.add('provenance_ledger',[{userId,artifactType,artifactId,provenance:{...normalized,hash},createdAt:now()}]);
    await audit(userId,'provenance.record','artifact',artifactId,{artifactType,hash}); return json({ok:Boolean(id),id,hash});
  }],

  'POST /api/xio/governance/evaluate': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401); const body=object(ctx.body); const resourceType=clean(body.resourceType,80), resourceId=clean(body.resourceId,200); if(!resourceType||!resourceId)return error('resourceType and resourceId are required',400);
    const risk=oneOf(body.risk,['low','medium','high','critical'],'medium') as Risk; const decision=actionDecision(risk,bool(body.hasApproval,false),bool(body.shadowPassed,false),bool(body.capabilityAllowed,false));
    const reasons:string[]=[]; if(!bool(body.capabilityAllowed,false))reasons.push('capability_not_allowed'); if(!bool(body.shadowPassed,false))reasons.push('shadow_not_passed'); if(['high','critical'].includes(risk)&&!bool(body.hasApproval,false))reasons.push('approval_required');
    const [id]=await db.add('governance_decisions',[{userId,resourceType,resourceId,decision,reasons,createdAt:now()}]); await audit(userId,'governance.evaluate',resourceType,resourceId,{risk,decision,reasons}); return json({ok:Boolean(id),id,decision,reasons});
  }],

  'POST /api/xio/actions/lease': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401); const body=object(ctx.body); const executionId=clean(body.executionId,200); const requestKey=clean(body.requestKey,200);
    if(!executionId||!requestKey)return error('executionId and requestKey are required',400); const [execution]=await db.get<any>('action_executions',[executionId]); if(!execution||execution.userId!==userId)return error('Execution not found',404); if(execution.status!=='started')return error('Execution is not leasable',409);
    const existing=await db.list<any>('action_leases',{limit:1000}); const live=existing.items.find(x=>x.executionId===executionId&&leaseValid({leaseId:x.id,executionId:x.executionId,expiresAt:x.expiresAt,attempt:Number(x.attempt)||1})); if(live)return json({ok:false,reason:'lease_exists',leaseId:live.id,expiresAt:live.expiresAt});
    const attempt=Number(body.attempt)||1; const leaseSecret=await connectorSigningSecret(); if(!leaseSecret) return error('Connector signing secret is not configured',503); const leaseToken=await hmacSha256(leaseSecret,idempotencyKey(userId,execution.actionIntentId,requestKey)); const expiresAt=new Date(Date.now()+Math.max(30,Math.min(900,Number(body.ttlSeconds)||120))*1000).toISOString();
    const [id]=await db.add('action_leases',[{executionId,leaseToken,attempt,expiresAt,createdAt:now()}]); await db.update('action_executions',[{id:executionId,record:{...execution,status:'leased',leaseId:id,attempt,updatedAt:now()}}]); await audit(userId,'action.lease.acquire','action_execution',executionId,{attempt,expiresAt}); return json({ok:Boolean(id),leaseId:id,leaseToken,attempt,expiresAt});
  }],

  'POST /api/xio/actions/retry-plan': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId)return error('Unauthorized',401); const body=object(ctx.body); const status=oneOf(body.status,['failed','completed','blocked','expired'],'failed') as any; const attempt=Math.max(1,Number(body.attempt)||1); const policy:RetryPolicy={maxAttempts:Math.max(1,Math.min(10,Number(body.maxAttempts)||3)),baseDelayMs:Math.max(100,Math.min(60000,Number(body.baseDelayMs)||1000)),maxDelayMs:Math.max(1000,Math.min(3600000,Number(body.maxDelayMs)||60000))}; const retry=canRetry(status,attempt,policy); const delay=retry?backoff(attempt,policy):0; await audit(userId,'action.retry_plan','action',undefined,{status,attempt,retry,delay}); return json({retry,delayMs:delay,nextAttempt:retry?attempt+1:null,policy});
  }],

  'POST /api/xio/contradictions/scan': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId)return error('Unauthorized',401); const body=object(ctx.body); const left=clean(body.left,MAX.memory), right=clean(body.right,MAX.memory); if(!left||!right)return error('left and right are required',400); const found=contradiction(left,right); const confidence=found?0.78:0.08; const [id]=found?await db.add('contradictions',[{userId,leftArtifact:clean(body.leftArtifact,200)||'left',rightArtifact:clean(body.rightArtifact,200)||'right',confidence,status:'open',createdAt:now()}]):[undefined]; await audit(userId,'memory.contradiction_scan','memory',id??undefined,{found,confidence}); return json({found,confidence,id,status:found?'open':'clear',learningDecision:learningDecision(false,confidence,found)});
  }],

  'GET /api/xio/audit/export': [requireAuth(), async (ctx:any) => {
    const userId=authGuard(ctx); if(!userId) return error('Unauthorized',401);
    const ent=await getEntitlement(userId); if(!ent.auditExport) return error('Audit export is not enabled for this plan',403);
    const rows=await db.list<Audit>('audit_events',{limit:1000}); const own=rows.items.filter(x=>x.userId===userId);
    await audit(userId,'audit.export','audit'); return json({generatedAt:now(),events:own});
  }],
});

export const retentionWorker = async (event:{type:'cron';payload?:{retentionDays?:number}})=>{
  const days=Math.max(1,Math.min(3650,Number(event.payload?.retentionDays??90)));
  const cutoff=Date.now()-days*86400000;
  for(const table of ['conversations','learning_signals']){
    const rows=await db.list<Record<string,unknown>>(table,{limit:1000});
    const ids=rows.items.filter(r=>typeof r.createdAt==='string'&&Date.parse(r.createdAt)<cutoff).map(r=>r.id).filter(Boolean) as string[];
    if(ids.length) await db.delete(table,ids);
  }
  return {statusCode:200,retentionDays:days};
};

export const learningWorker = async ()=>({statusCode:200,promoted:0,governance:'explicit-user-decision'});
