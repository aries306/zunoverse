import { secrets } from '@appdeploy/sdk';

export async function readSecret(name:string):Promise<string>{
  try { return await secrets.readSecret(name); } catch { return ''; }
}

export async function hasSecret(name:string):Promise<boolean>{
  try { return (await secrets.listSecretNames()).includes(name); } catch { return false; }
}

export async function firstSecret(...names:string[]):Promise<{name:string;value:string}|undefined>{
  const configured=new Set(await secrets.listSecretNames());
  for(const name of names){ if(configured.has(name)){ try { const value=await secrets.readSecret(name); if(value) return {name,value}; } catch {} } }
  return undefined;
}

export async function csvSecret(name:string):Promise<string[]>{
  const value=await readSecret(name);
  return value.split(',').map(x=>x.trim()).filter(Boolean).slice(0,50);
}
