const enc = new TextEncoder();
const toHex=(bytes:Uint8Array)=>Array.from(bytes).map(b=>b.toString(16).padStart(2,'0')).join('');

export async function hmacSha256(secret:string,payload:string){
  const cryptoApi=(globalThis as any).crypto;
  if(!cryptoApi?.subtle) throw new Error('WebCrypto is required');
  const key=await cryptoApi.subtle.importKey('raw',enc.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);
  return toHex(new Uint8Array(await cryptoApi.subtle.sign('HMAC',key,enc.encode(payload))));
}

export async function verifyHmac(secret:string,payload:string,signature:string){
  const expected=await hmacSha256(secret,payload);
  if(expected.length!==signature.length) return false;
  let diff=0; for(let i=0;i<expected.length;i++) diff |= expected.charCodeAt(i)^signature.charCodeAt(i);
  return diff===0;
}
