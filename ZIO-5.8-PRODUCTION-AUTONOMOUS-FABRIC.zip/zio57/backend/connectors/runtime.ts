export type ExecutionStatus='queued'|'leased'|'completed'|'failed'|'blocked'|'expired';
export type RetryPolicy={maxAttempts:number;baseDelayMs:number;maxDelayMs:number};
export type Lease={leaseId:string;executionId:string;expiresAt:string;attempt:number};
export function backoff(attempt:number,p:RetryPolicy){ const n=Math.max(0,attempt-1); return Math.min(p.maxDelayMs,p.baseDelayMs*Math.pow(2,n)); }
export function canRetry(status:ExecutionStatus,attempt:number,p:RetryPolicy){ return status==='failed' && attempt < Math.max(1,p.maxAttempts); }
export function leaseValid(lease:Lease, nowMs=Date.now()){ return Date.parse(lease.expiresAt)>nowMs; }
export function idempotencyKey(userId:string, actionIntentId:string, requestKey:string){ return `${userId}:${actionIntentId}:${requestKey}`.slice(0,500); }
