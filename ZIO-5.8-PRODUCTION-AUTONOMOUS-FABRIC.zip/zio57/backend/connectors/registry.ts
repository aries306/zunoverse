export type Provider = 'google'|'microsoft'|'github'|'notion'|'slack'|'linear'|'custom';
export type OAuthConfig = { authorizeUrl:string; scopes:string[] };
export type ConnectorCapability = 'read'|'write';

const configs:Record<Provider,OAuthConfig> = {
  google:{authorizeUrl:'https://accounts.google.com/o/oauth2/v2/auth',scopes:['openid','email','profile']},
  microsoft:{authorizeUrl:'https://login.microsoftonline.com/common/oauth2/v2.0/authorize',scopes:['openid','email','profile']},
  github:{authorizeUrl:'https://github.com/login/oauth/authorize',scopes:['read:user','user:email']},
  notion:{authorizeUrl:'https://api.notion.com/v1/oauth/authorize',scopes:[]},
  slack:{authorizeUrl:'https://slack.com/oauth/v2/authorize',scopes:[]},
  linear:{authorizeUrl:'https://linear.app/oauth/authorize',scopes:['read']},
  custom:{authorizeUrl:'',scopes:[]}
};

export function isProvider(v:unknown):v is Provider { return typeof v==='string' && v in configs; }
export function oauthConfig(provider:Provider){ return configs[provider]; }
export function buildAuthorizeUrl(provider:Provider,state:string,clientId:string,redirectUri:string,scopes:string[]=[]){
  const cfg=configs[provider]; if(!cfg.authorizeUrl) throw new Error('Custom provider requires connector-managed authorization');
  const url=new URL(cfg.authorizeUrl); url.searchParams.set('state',state); url.searchParams.set('client_id',clientId); url.searchParams.set('redirect_uri',redirectUri);
  if(scopes.length) url.searchParams.set('scope',[...new Set([...cfg.scopes,...scopes])].join(' '));
  if(provider==='google') url.searchParams.set('response_type','code');
  return url.toString();
}

export const providerCapabilities:Record<Provider,ConnectorCapability[]> = {
  google:['read','write'],microsoft:['read','write'],github:['read','write'],notion:['read','write'],slack:['read','write'],linear:['read','write'],custom:['read']
};
