export type OAuthState = { nonce:string; userId:string; provider:string; redirectUri:string; expiresAt:string };
export function makeNonce(bytes=24){ const c=(globalThis as any).crypto; if(c?.getRandomValues){ const b=new Uint8Array(bytes); c.getRandomValues(b); return Array.from(b).map((x:number)=>x.toString(16).padStart(2,'0')).join(''); } return `${Date.now()}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`; }
export function statePayload(s:OAuthState){ return JSON.stringify(s); }
export function stateExpired(s:OAuthState, nowMs=Date.now()){ return Date.parse(s.expiresAt) <= nowMs; }
export function validRedirectUri(uri:string, allowlist:string[]){ try { const u=new URL(uri); return u.protocol==='https:' && allowlist.includes(u.toString()); } catch { return false; } }
export function encodeState(payload:string,signature:string){ return `${btoa(payload)}.${signature}`; }
export function decodeState(state:string){ const i=state.lastIndexOf('.'); if(i<=0) throw new Error('Invalid OAuth state'); return {payload:atob(state.slice(0,i)),signature:state.slice(i+1)}; }
