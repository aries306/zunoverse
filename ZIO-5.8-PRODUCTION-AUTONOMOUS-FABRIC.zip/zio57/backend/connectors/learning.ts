export type LearningSignal = {
  kind:'accepted_memory'|'verified_outcome'|'rejected_memory'|'action_result';
  confidence:number;
  evidence:string[];
  sourceIds:string[];
};

export function deriveLearningSignal(input:{kind:LearningSignal['kind'];confidence:number;evidence?:string[];sourceIds?:string[]}):LearningSignal{
  return {kind:input.kind,confidence:Math.max(0,Math.min(1,input.confidence)),evidence:(input.evidence??[]).slice(0,20),sourceIds:(input.sourceIds??[]).slice(0,20)};
}
