export type Chunk = { id:string; documentId:string; index:number; text:string; tokenEstimate:number };

export function chunkText(documentId:string,text:string,maxChars=2400,overlap=240):Chunk[]{
  const normalized=text.replace(/\s+/g,' ').trim(); if(!normalized) return [];
  const chunks:Chunk[]=[]; let start=0,index=0;
  while(start<normalized.length){
    let end=Math.min(normalized.length,start+maxChars);
    if(end<normalized.length){ const boundary=normalized.lastIndexOf(' ',end); if(boundary>start+Math.floor(maxChars*.55)) end=boundary; }
    const part=normalized.slice(start,end).trim();
    if(part) chunks.push({id:`${documentId}:${index}`,documentId,index,text:part,tokenEstimate:Math.ceil(part.length/4)});
    if(end>=normalized.length) break;
    start=Math.max(start+1,end-overlap); index++;
  }
  return chunks;
}

export function scoreChunk(query:string,text:string){
  const terms=[...new Set(query.toLowerCase().split(/\W+/).filter(x=>x.length>2))]; if(!terms.length) return 0;
  const hay=text.toLowerCase(); let score=0;
  for(const term of terms){ if(hay.includes(term)) score += 1 + (hay.split(term).length-1)*.05; }
  return score/terms.length;
}
