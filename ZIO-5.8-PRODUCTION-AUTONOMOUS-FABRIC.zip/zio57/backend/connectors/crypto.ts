function bytesToBase64(bytes:Uint8Array){ let s=''; for(const b of bytes) s+=String.fromCharCode(b); return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,''); }
function base64ToBytes(value:string){ const padded=value.replace(/-/g,'+').replace(/_/g,'/')+'==='.slice((value.length+3)%4); const s=atob(padded); return Uint8Array.from(s,c=>c.charCodeAt(0)); }

export async function encryptText(plaintext:string,keyMaterial:string){
  if(!keyMaterial) throw new Error('Encryption key is not configured');
  const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(keyMaterial));
  const key=await crypto.subtle.importKey('raw',digest,{name:'AES-GCM'},false,['encrypt','decrypt']);
  const iv=crypto.getRandomValues(new Uint8Array(12));
  const ciphertext=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv},key,new TextEncoder().encode(plaintext)));
  return `v1.${bytesToBase64(iv)}.${bytesToBase64(ciphertext)}`;
}

export async function decryptText(payload:string,keyMaterial:string){
  if(!keyMaterial) throw new Error('Encryption key is not configured');
  const [version,ivText,cipherText]=payload.split('.'); if(version!=='v1'||!ivText||!cipherText) throw new Error('Invalid encrypted payload');
  const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(keyMaterial));
  const key=await crypto.subtle.importKey('raw',digest,{name:'AES-GCM'},false,['encrypt','decrypt']);
  const plaintext=await crypto.subtle.decrypt({name:'AES-GCM',iv:base64ToBytes(ivText)},key,base64ToBytes(cipherText));
  return new TextDecoder().decode(plaintext);
}
