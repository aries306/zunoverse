export type OAuthTokens={accessToken:string;refreshToken?:string;expiresIn?:number;tokenType?:string;scope?:string;raw?:Record<string,unknown>};

type ProviderConfig={tokenUrl:string;clientAuth:'basic'|'body';parse:(data:Record<string,unknown>)=>OAuthTokens};

const configs:Record<string,ProviderConfig>={
  google:{tokenUrl:'https://oauth2.googleapis.com/token',clientAuth:'body',parse:parseStandard},
  microsoft:{tokenUrl:'https://login.microsoftonline.com/common/oauth2/v2.0/token',clientAuth:'body',parse:parseStandard},
  github:{tokenUrl:'https://github.com/login/oauth/access_token',clientAuth:'body',parse:parseStandard},
  notion:{tokenUrl:'https://api.notion.com/v1/oauth/token',clientAuth:'basic',parse:parseStandard},
  slack:{tokenUrl:'https://slack.com/api/oauth.v2.access',clientAuth:'body',parse:parseSlack},
  linear:{tokenUrl:'https://api.linear.app/oauth/token',clientAuth:'body',parse:parseStandard}
};

function parseStandard(data:Record<string,unknown>):OAuthTokens{
  const accessToken=typeof data.access_token==='string'?data.access_token:''; if(!accessToken) throw new Error('Provider did not return an access token');
  return {accessToken,refreshToken:typeof data.refresh_token==='string'?data.refresh_token:undefined,expiresIn:typeof data.expires_in==='number'?data.expires_in:undefined,tokenType:typeof data.token_type==='string'?data.token_type:undefined,scope:typeof data.scope==='string'?data.scope:undefined,raw:data};
}
function parseSlack(data:Record<string,unknown>):OAuthTokens{ if(data.ok===false) throw new Error('Slack OAuth exchange failed'); return parseStandard(data); }

export function providerConfig(provider:string){ return configs[provider]; }

export async function exchangeCode(provider:string,code:string,redirectUri:string,clientId:string,clientSecret:string):Promise<OAuthTokens>{
  const cfg=configs[provider]; if(!cfg) throw new Error('Unsupported OAuth provider');
  const params=new URLSearchParams({client_id:clientId,client_secret:clientSecret,code,redirect_uri:redirectUri});
  const headers:Record<string,string>={'content-type':'application/x-www-form-urlencoded','accept':'application/json'};
  if(cfg.clientAuth==='basic'){ headers.authorization=`Basic ${btoa(`${clientId}:${clientSecret}`)}`; params.delete('client_id'); params.delete('client_secret'); }
  const response=await fetch(cfg.tokenUrl,{method:'POST',headers,body:params.toString()});
  const text=await response.text(); let data:Record<string,unknown>={}; try{ data=JSON.parse(text) as Record<string,unknown>; }catch{ throw new Error(`OAuth provider returned non-JSON response (${response.status})`); }
  if(!response.ok) throw new Error(`OAuth token exchange failed (${response.status})`);
  return cfg.parse(data);
}

export async function refreshToken(provider:string,refresh:string,clientId:string,clientSecret:string):Promise<OAuthTokens>{
  const cfg=configs[provider]; if(!cfg) throw new Error('Unsupported OAuth provider');
  const params=new URLSearchParams({client_id:clientId,client_secret:clientSecret,grant_type:'refresh_token',refresh_token:refresh});
  const headers:Record<string,string>={'content-type':'application/x-www-form-urlencoded','accept':'application/json'};
  if(cfg.clientAuth==='basic'){ headers.authorization=`Basic ${btoa(`${clientId}:${clientSecret}`)}`; params.delete('client_id'); params.delete('client_secret'); }
  const response=await fetch(cfg.tokenUrl,{method:'POST',headers,body:params.toString()});
  const text=await response.text(); let data:Record<string,unknown>={}; try{ data=JSON.parse(text) as Record<string,unknown>; }catch{ throw new Error(`OAuth refresh returned non-JSON response (${response.status})`); }
  if(!response.ok) throw new Error(`OAuth refresh failed (${response.status})`);
  const parsed=cfg.parse(data); if(!parsed.refreshToken) parsed.refreshToken=refresh; return parsed;
}
