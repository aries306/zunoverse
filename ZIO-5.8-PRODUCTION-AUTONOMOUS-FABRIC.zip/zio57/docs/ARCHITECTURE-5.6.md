# ZIO 5.6 — Real Connector Runtime + Semantic Intelligence Contract

5.6 is represented inside the 5.7 release as the runtime layer beneath the autonomous fabric.

It defines: OAuth lifecycle state, provider adapter boundaries, action idempotency, execution leases, retry/backoff, persistent source chunks, hybrid retrieval dimensions, provenance, and evidence flow.

Live provider credentials, token exchange/refresh and external API calls remain deployment adapters rather than being faked in the core package.
