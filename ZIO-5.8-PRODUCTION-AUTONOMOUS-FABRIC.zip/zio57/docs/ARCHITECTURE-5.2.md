# ZIO 5.2 Intelligence Architecture

Context -> retrieval -> reasoning -> recommendation -> optional action -> outcome -> verification -> learning proposal -> explicit memory governance.

## Work Graph
Tenant-owned typed nodes and edges. Edge creation requires ownership of both endpoints, preventing cross-tenant graph links.

## Shadow
Simulation-only. It may predict consequences and reversible next steps but has no action-execution capability. Runs are persisted for auditability.

## Outcome learning
Recommendations and real-world outcomes are separate records. Verification defaults to false and must be explicitly supplied by a user or trusted integration.

## Contextual memory
Dormant memories may be reactivated, but reactivation marks them unverified so they must be re-evaluated before becoming trusted context. Memory remains distinct from recommendation, belief, insight and prediction.

## Provider integrations
OAuth Source Fabric and billing remain adapter boundaries. Production enablement requires real provider credentials, callbacks/webhooks, signature validation and staging integration tests.
