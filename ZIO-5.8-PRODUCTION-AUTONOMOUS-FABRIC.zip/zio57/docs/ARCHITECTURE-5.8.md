# ZIO 5.8 — Production Autonomous Intelligence Fabric

ZIO 5.8 closes the fixable production gaps identified in 5.7 while keeping hard external dependencies explicit.

## New control-plane guarantees
- AppDeploy-managed secrets replace process environment access for connector credentials.
- Connector authentication and connector HMAC signing use separate secrets.
- OAuth state is random, signed, persisted, expiring and one-time consumable.
- Provider client IDs/secrets are server-side only.
- OAuth callback performs provider token exchange for supported providers: Google, Microsoft, GitHub, Notion, Slack and Linear.
- User connector tokens are encrypted at rest with AES-GCM before persistence.
- Refresh-token rotation is supported through the provider token endpoint.
- Action dispatch requires a caller-supplied request key and durable idempotency record.
- Provider side effects remain outside the core; only registered connector executors may perform them.
- Configuration status exposes readiness booleans, never secret values.

## Core loop
Context → Contextual Memory → Work Graph → Connected Sources → Hybrid Retrieval → Reasoning → Shadow → Governance → Idempotent Action → Connector Runtime → Evidence → Outcome Verification → Contradiction Scan → Learning Candidate → Memory Re-evaluation.

## Deliberate boundary
5.8 does not claim that provider credentials are configured, that a particular provider account is connected, or that production vector infrastructure/WAF/billing/backup systems exist. Those are deployment facts, not code features.
