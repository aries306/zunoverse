# ZIO 5.5 — Connector + Retrieval Fabric

## Control plane
ZIO core owns identity, tenant isolation, memory governance, graph state, action intents, and outcome verification.

## Connector plane
A dedicated connector service owns provider credentials, OAuth token exchange/refresh, provider API calls, webhooks, and external side effects. Core accepts only authenticated, signed connector events/results.

## Retrieval plane
Documents are normalized, checksummed, chunked deterministically, then ranked. Semantic/vector infrastructure can be added behind the same retrieval contract without changing memory or source provenance semantics.

## Learning boundary
Only explicit user decisions, verified outcomes, or signed connector results may produce durable learning signals. Learning signals remain distinct from memories and recommendations.

## Security invariants
- Never accept raw provider secrets from the browser.
- Never execute arbitrary URLs from an action intent.
- Require connector authentication and HMAC verification for connector callbacks.
- Enforce idempotency on external event IDs.
- Preserve tenant ownership on every persisted record.
