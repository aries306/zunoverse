import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';

const root=path.resolve(new URL('..', import.meta.url).pathname);
const backend=fs.readFileSync(path.join(root,'backend/index.ts'),'utf8');
const cloud=fs.readFileSync(path.join(root,'build/js/cloud.js'),'utf8');
const jsDir=path.join(root,'build/js');
const js=fs.readdirSync(jsDir).filter(f=>f.endsWith('.js'));
const checks=[];
const ok=(name,condition)=>checks.push([name,Boolean(condition)]);

for(const f of js){const r=spawnSync(process.execPath,['--check',path.join(jsDir,f)],{encoding:'utf8'}); ok(`JS syntax: ${f}`,r.status===0);}
ok('All user-facing routes require authentication', (backend.match(/requireAuth\(\)/g)||[]).length >= 10);
ok('Turn endpoint ignores client-supplied authoritative prefs', !backend.includes('prefs:body.prefs') && !backend.includes('profile:body.profile'));
ok('Turn endpoint uses stored profile/preferences', backend.includes('const stored=await getProfile(userId)'));
ok('Memory decisions validate accept/reject', backend.includes("Decision must be accept or reject"));
ok('Memory decisions enforce ownership', backend.includes("!m||m.userId!==userId"));
ok('Background worker cannot silently promote memory', backend.includes('governance:\'explicit-user-decision\''));
ok('Reset retains security audit trail', backend.includes('auditRetained:true') && backend.includes("audit(userId,'data.reset'"));
ok('Intelligence Fabric context route exists', backend.includes("GET /api/xio/context"));
ok('Action approval is explicit', backend.includes('requiresExplicitApproval:true'));
ok('Outcome verification route exists', backend.includes("POST /api/xio/outcomes/verify"));
ok('Billing fails closed', backend.includes('Billing provider is not configured'));
ok('Cloud confirmation sends server memory id', cloud.includes("{id:memory.id, memory}"));
ok('Cloud reset propagates failure', cloud.includes("async function reset() { await requireUser();"));
ok('5.4 source sync is exposed', cloud.includes('syncSource'));
ok('5.4 governed execution is exposed', cloud.includes('executeAction'));
ok('5.4 outcome verification is exposed', cloud.includes('verifyOutcome'));
const failed=checks.filter(x=>!x[1]);
for(const [n,p] of checks) console.log(`${p?'PASS':'FAIL'} ${n}`);
if(failed.length){console.error(`\\n${failed.length} test(s) failed.`);process.exit(1);}
console.log(`\\n${checks.length} checks passed.`);
