import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const registry=readFileSync(new URL('../backend/connectors/registry.ts',import.meta.url),'utf8');
const security=readFileSync(new URL('../backend/connectors/security.ts',import.meta.url),'utf8');
const retrieval=readFileSync(new URL('../backend/connectors/retrieval.ts',import.meta.url),'utf8');
const backend=readFileSync(new URL('../backend/index.ts',import.meta.url),'utf8');

assert.match(registry,/buildAuthorizeUrl/);
assert.match(registry,/providerCapabilities/);
assert.match(security,/HMAC/);
assert.match(security,/constant-time|diff===0/);
assert.match(retrieval,/chunkText/);
assert.match(retrieval,/scoreChunk/);
for (const route of ['/api/xio/connectors/oauth-url','/api/xio/connectors/webhook','/api/xio/connectors/ingest','/api/xio/connectors/action-result']) assert.match(backend,new RegExp(route.replaceAll('/','\\/')));
assert.match(backend,/connectorAuthorized/);
assert.match(backend,/duplicate:true/);
assert.match(backend,/deriveLearningSignal/);
console.log('ZIO 5.5 fabric checks: PASS');
