declare module '@appdeploy/sdk' {
  export const router: (routes: Record<string, any>) => any;
  export const json: (body:any) => any;
  export const error: (message:string,status:number) => any;
  export const requireAuth: () => any;
  export const db: {
    list:<T=any>(table:string,opts:any)=>Promise<{items:(T & {id:string})[]}>;
    add:<T=any>(table:string,rows:T[])=>Promise<string[]>;
    get:<T=any>(table:string,ids:string[])=>Promise<(T & {id:string})[]>;
    update:<T=any>(table:string,rows:any[])=>Promise<any>;
    delete:(table:string,ids:string[])=>Promise<any>;
  };
  export const ai: {run:(args:any)=>Promise<any>};
}

declare module '@appdeploy/sdk' {
  export const secrets: {
    readSecret(name: string): Promise<string>;
    listSecretNames(): Promise<string[]>;
  };
}
