import fs from 'node:fs';
const b=fs.readFileSync(new URL('../backend/index.ts',import.meta.url),'utf8');
const checks=[
 ['Work Graph node endpoint exists',b.includes("POST /api/xio/graph/nodes")],
 ['Graph ownership is enforced',b.includes("owned.has(fromId)||!owned.has(toId)")],
 ['Shadow is simulation-only',b.includes('without executing actions')],
 ['Shadow persists runs',b.includes("db.add('shadow_runs'")],
 ['Outcomes default to unverified',b.includes('const verified=bool(body.verified,false)')],
 ['Dormant memory reactivation forces reevaluation',b.includes('requiresReevaluation:true')],
 ['New intelligence routes require auth',b.includes("POST /api/xio/shadow/simulate': [requireAuth()") && b.includes("POST /api/xio/outcomes': [requireAuth()")],
];
for(const [n,v] of checks) console.log(`${v?'PASS':'FAIL'} ${n}`);
if(checks.some(([,v])=>!v)) process.exit(1);
