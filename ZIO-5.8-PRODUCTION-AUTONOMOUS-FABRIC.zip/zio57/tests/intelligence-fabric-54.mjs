import fs from 'node:fs';
const b=fs.readFileSync(new URL('../backend/index.ts',import.meta.url),'utf8');
const m=fs.readFileSync(new URL('../migrations/003_source_ingestion_execution.sql',import.meta.url),'utf8');
const c=fs.readFileSync(new URL('../build/js/cloud.js',import.meta.url),'utf8');
const checks=[
 ['Source ingestion endpoint exists',b.includes("POST /api/xio/sources/sync")],
 ['Source ingestion enforces connection ownership',b.includes("connection.userId!==userId")],
 ['Source documents are checksum-addressed',b.includes("digest(`${externalId}\\n${title}\\n${content}`)") && m.includes('checksum')],
 ['Source search endpoint exists',b.includes("GET /api/xio/sources/search")],
 ['Source context is included in AI turns',b.includes('sources:sources.map')],
 ['Context retrieval returns source documents',b.includes('sourceCount:sourceMatches.length')],
 ['Action execution dispatch is connector-only',b.includes("allowedExecutors=['connector-service']")],
 ['Core never performs external side effects directly',b.includes('sideEffectPerformed:false')],
 ['Execution result requires started state',b.includes("execution.status!=='started'")],
 ['Execution persistence migration exists',m.includes('create table if not exists action_executions')],
 ['Cloud exposes source sync',c.includes('syncSource')],
 ['Cloud exposes governed execution',c.includes('executeAction')],
 ['Cloud exposes outcome verification',c.includes('verifyOutcome')],
];
for(const [n,v] of checks) console.log(`${v?'PASS':'FAIL'} ${n}`);
if(checks.some(([,v])=>!v)) process.exit(1);
