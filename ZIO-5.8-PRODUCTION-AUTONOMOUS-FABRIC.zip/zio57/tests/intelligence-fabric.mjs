import fs from 'node:fs';
const b=fs.readFileSync(new URL('../backend/index.ts',import.meta.url),'utf8');
const m=fs.readFileSync(new URL('../migrations/002_intelligence_fabric.sql',import.meta.url),'utf8');
const checks=[
 ['Context retrieval route exists',b.includes("GET /api/xio/context")],
 ['Context retrieval is authenticated',b.includes("GET /api/xio/context': [requireAuth()")],
 ['OAuth source registry exists',b.includes("POST /api/xio/sources/connect") && m.includes('source_connections')],
 ['Credentials remain server-side',b.includes('credentialsMustRemainServerSide:true')],
 ['Action execution remains gated',b.includes('requiresExplicitApproval:true') && b.includes('execution:false')],
 ['High-impact actions require policy approval',b.includes('High-impact actions require an external policy approval workflow')],
 ['Outcome verification persists evidence',b.includes("db.add('outcome_verifications'")],
 ['Telemetry is tenant scoped',b.includes("x.userId===userId") && b.includes("POST /api/xio/telemetry")],
 ['Telemetry summary computes p95',b.includes('p95LatencyMs')],
];
for(const [n,v] of checks) console.log(`${v?'PASS':'FAIL'} ${n}`);
if(checks.some(([,v])=>!v)) process.exit(1);
