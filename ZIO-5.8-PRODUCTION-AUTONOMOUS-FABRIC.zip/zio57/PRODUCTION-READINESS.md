# ZIO 5.8 Production Readiness

## Implemented in package
- Tenant ownership checks on protected resources.
- Separate connector authentication and HMAC signing secrets.
- AppDeploy-managed secret access; no process.env credential dependency.
- Random, signed, expiring, persisted, one-time OAuth state.
- Server-side provider client configuration.
- Real OAuth code exchange adapters for Google, Microsoft, GitHub, Notion, Slack and Linear.
- AES-GCM encrypted user connector-token persistence and refresh flow.
- Durable action idempotency records, execution leases, retry planning and dead-letter schema.
- Durable provenance and governance decisions.
- Contradiction detection with learning re-evaluation.
- Hybrid retrieval with explicit semantic-provider readiness signal.
- Strict TypeScript contract tests and regression/fabric tests.

## Remaining deployment facts, not safely inventable in code
1. Bind real AppDeploy secrets for connector auth/signing, token encryption, OAuth redirect allowlist and enabled provider credentials.
2. Apply migrations 001–006 in staging and execute rollback/restore drills.
3. Configure a real embedding/vector service before labeling results semantic; lexical-only mode remains honest fallback.
4. Replace bounded scans with server-side indexed/paginated access once the production database contract is confirmed.
5. Put distributed WAF/rate limiting/circuit breaking and centralized tracing around the runtime.
6. Complete provider-specific action adapters and least-privilege scopes for the exact actions ZIO will expose.
7. Enforce high/critical actions through the dedicated approval workflow and human escalation.
8. Run authenticated provider integration tests, replay tests, key-rotation tests and disaster-recovery tests against staging accounts.
9. Configure verified billing webhooks and backup/restore automation if billing is enabled.

**Release posture:** production-hardened architecture and live OAuth/token-runtime code paths are present, but third-party connectivity is not claimed until credentials, staging verification and provider-specific action tests are green.
