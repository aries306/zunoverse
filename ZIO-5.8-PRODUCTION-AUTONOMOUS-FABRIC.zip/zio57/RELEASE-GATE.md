# ZIO 5.8 Release Gate

## Package validation
- [x] Legacy JavaScript syntax checks pass.
- [x] 5.1–5.7 regression/fabric checks pass.
- [x] OAuth state is random, signed, persisted, expiring and one-time consumable.
- [x] Connector auth and HMAC signing are separated.
- [x] Provider credentials are server-side only.
- [x] OAuth exchange/refresh adapters exist for six supported providers.
- [x] Connector tokens are encrypted before persistence.
- [x] Action dispatch has durable idempotency protection.
- [x] Action lease/retry/dead-letter primitives remain intact.
- [x] Provenance/governance/contradiction controls remain intact.
- [x] Strict TypeScript contract check passes.

## Hard blockers before production
- [ ] Real AppDeploy secrets bound and verified in staging.
- [ ] Migrations 001–006 applied and rollback/restore tested.
- [ ] At least one real provider connection completed end-to-end in staging.
- [ ] Provider-specific action adapters tested with least privilege.
- [ ] Real embeddings/vector index configured and benchmarked.
- [ ] Indexed/paginated DB access validated for production scale.
- [ ] Distributed WAF/rate limiting/circuit breaking and centralized tracing enabled.
- [ ] High/critical approval and human escalation workflow verified.
- [ ] Replay, secret-rotation and adversarial security evaluation green.
- [ ] Backup/restore and disaster recovery green.
- [ ] Billing webhook verification green if billing is enabled.

**Release posture:** deployable and significantly hardened; no claim of live third-party connectivity until staging evidence turns the remaining gates green.
