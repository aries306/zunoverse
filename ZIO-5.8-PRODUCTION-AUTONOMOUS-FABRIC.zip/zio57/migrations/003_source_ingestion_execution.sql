create table if not exists source_documents (
  id uuid primary key default gen_random_uuid(), user_id text not null, connection_id uuid not null,
  external_id text not null, title text not null, content text not null, url text, mime_type text,
  checksum text not null, metadata jsonb not null default '{}'::jsonb,
  indexed_at timestamptz not null, updated_at timestamptz not null
);
create unique index if not exists uq_source_documents_owner_external on source_documents(user_id, connection_id, external_id);
create index if not exists idx_source_documents_user_updated on source_documents(user_id, updated_at desc);
create index if not exists idx_source_documents_user_connection on source_documents(user_id, connection_id, updated_at desc);

create table if not exists source_syncs (
  id uuid primary key default gen_random_uuid(), user_id text not null, connection_id uuid not null,
  status text not null, received integer not null default 0, indexed integer not null default 0,
  failed integer not null default 0, cursor text, error text, started_at timestamptz not null, completed_at timestamptz,
  check(status in ('running','completed','failed'))
);
create index if not exists idx_source_syncs_user_connection on source_syncs(user_id, connection_id, started_at desc);

create table if not exists action_executions (
  id uuid primary key default gen_random_uuid(), user_id text not null, action_intent_id uuid not null,
  executor text not null, status text not null, external_ref text, result jsonb not null default '{}'::jsonb,
  error text, created_at timestamptz not null, completed_at timestamptz,
  check(status in ('started','completed','failed','blocked'))
);
create index if not exists idx_action_executions_user_created on action_executions(user_id, created_at desc);
create index if not exists idx_action_executions_intent on action_executions(action_intent_id, created_at desc);
