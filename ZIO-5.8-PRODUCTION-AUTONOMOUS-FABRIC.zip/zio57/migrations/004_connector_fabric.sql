-- ZIO 5.5 Connector Fabric: idempotent events, chunked retrieval, verified connector actions.
create table if not exists connector_events (
  id text primary key,
  event_id text not null unique,
  user_id text not null,
  type text not null,
  payload jsonb not null default '{}'::jsonb,
  received_at timestamptz not null
);
create index if not exists connector_events_user_received_idx on connector_events(user_id, received_at desc);
create index if not exists connector_events_type_idx on connector_events(type);

create table if not exists source_chunks (
  id text primary key,
  user_id text not null,
  document_id text not null,
  chunk_index integer not null,
  content text not null,
  token_estimate integer not null,
  created_at timestamptz not null,
  unique(document_id, chunk_index)
);
create index if not exists source_chunks_user_document_idx on source_chunks(user_id, document_id, chunk_index);

create table if not exists learning_signals (
  id text primary key,
  user_id text not null,
  source text not null,
  signal jsonb not null,
  created_at timestamptz not null
);
create index if not exists learning_signals_user_created_idx on learning_signals(user_id, created_at desc);
