-- ZIO 5.8: encrypted connector tokens, replay-safe OAuth, execution idempotency and operational metadata.
create table if not exists connector_tokens (
  id text primary key,
  user_id text not null,
  provider text not null,
  encrypted text not null,
  key_version text not null,
  scope text,
  expires_at timestamptz,
  created_at timestamptz not null,
  updated_at timestamptz not null
);
create index if not exists connector_tokens_user_provider_idx on connector_tokens(user_id, provider, updated_at desc);

create table if not exists action_idempotency (
  id text primary key,
  user_id text not null,
  idempotency_key text not null unique,
  execution_id text not null,
  created_at timestamptz not null
);
create index if not exists action_idempotency_user_idx on action_idempotency(user_id, created_at desc);

create table if not exists operational_incidents (
  id text primary key,
  user_id text,
  severity text not null,
  component text not null,
  status text not null,
  fingerprint text not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null,
  resolved_at timestamptz
);
create index if not exists operational_incidents_status_idx on operational_incidents(status, created_at desc);
