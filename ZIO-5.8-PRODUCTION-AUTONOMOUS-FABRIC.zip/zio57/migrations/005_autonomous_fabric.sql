-- ZIO 5.6/5.7: runtime, semantic retrieval, provenance and governance.
create table if not exists oauth_states (id text primary key, user_id text not null, provider text not null, nonce text not null unique, redirect_uri text not null, expires_at timestamptz not null, consumed_at timestamptz);
create index if not exists oauth_states_user_idx on oauth_states(user_id, expires_at desc);
create table if not exists action_leases (id text primary key, execution_id text not null unique, lease_token text not null unique, attempt integer not null, expires_at timestamptz not null, created_at timestamptz not null);
create table if not exists action_dead_letters (id text primary key, execution_id text not null, reason text not null, payload jsonb not null default '{}'::jsonb, created_at timestamptz not null);
create table if not exists retrieval_embeddings (id text primary key, user_id text not null, chunk_id text not null unique, model text not null, dimensions integer not null, vector jsonb not null, created_at timestamptz not null);
create index if not exists retrieval_embeddings_user_idx on retrieval_embeddings(user_id, created_at desc);
create table if not exists provenance_ledger (id text primary key, user_id text not null, artifact_type text not null, artifact_id text not null, provenance jsonb not null, created_at timestamptz not null);
create index if not exists provenance_ledger_artifact_idx on provenance_ledger(user_id, artifact_type, artifact_id);
create table if not exists governance_decisions (id text primary key, user_id text not null, resource_type text not null, resource_id text not null, decision text not null, reasons jsonb not null default '[]'::jsonb, created_at timestamptz not null);
create index if not exists governance_decisions_user_idx on governance_decisions(user_id, created_at desc);
create table if not exists contradictions (id text primary key, user_id text not null, left_artifact text not null, right_artifact text not null, confidence numeric not null, status text not null, created_at timestamptz not null);
create index if not exists contradictions_user_idx on contradictions(user_id, created_at desc);
