
create table if not exists source_connections (
  id uuid primary key default gen_random_uuid(), user_id text not null, provider text not null,
  status text not null default 'pending', scopes jsonb not null default '[]'::jsonb,
  external_account_id text, metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null, updated_at timestamptz not null,
  check (status in ('pending','connected','revoked','error'))
);
create unique index if not exists uq_source_connections_user_provider_account on source_connections(user_id, provider, external_account_id);
create index if not exists idx_source_connections_user_status on source_connections(user_id, status, updated_at desc);

create table if not exists action_intents (
  id uuid primary key default gen_random_uuid(), user_id text not null, action text not null,
  target text, parameters jsonb not null default '{}'::jsonb, risk text not null default 'medium',
  status text not null default 'proposed', shadow_run_id uuid, approved_at timestamptz,
  executed_at timestamptz, result jsonb, created_at timestamptz not null, updated_at timestamptz not null,
  check (risk in ('low','medium','high','critical')),
  check (status in ('proposed','approved','executed','rejected','failed','expired'))
);
create index if not exists idx_action_intents_user_status_created on action_intents(user_id, status, created_at desc);

create table if not exists outcome_verifications (
  id uuid primary key default gen_random_uuid(), user_id text not null, outcome_id uuid not null,
  verifier text not null, evidence jsonb not null default '{}'::jsonb, verdict text not null,
  created_at timestamptz not null,
  check (verdict in ('verified','rejected','inconclusive'))
);
create index if not exists idx_outcome_verifications_user_outcome on outcome_verifications(user_id, outcome_id, created_at desc);

create table if not exists observability_events (
  id uuid primary key default gen_random_uuid(), user_id text, trace_id text not null,
  event text not null, latency_ms integer, success boolean, metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null
);
create index if not exists idx_observability_trace_created on observability_events(trace_id, created_at desc);
create index if not exists idx_observability_user_created on observability_events(user_id, created_at desc);
