# ZIO 5.5 regression and fabric tests

1. Secure sign-in and protected bootstrap.
2. Conversation + governed memory learning.
3. Context retrieval across memory, source, and Work Graph with tenant isolation.
4. Connector boundary: signed webhook/action result accepted; unsigned or replayed event rejected/idempotent.
5. Governed action + outcome verification: approval, execution dispatch, connector result, and evidence verification remain distinct.
6. Retrieval chunking: deterministic chunks preserve document provenance and bounded size.
7. JavaScript syntax and package integrity.
